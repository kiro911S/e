import { config } from "dotenv";
import { PrismaClient, ProgramStatus, Role, TestResultStatus, UserStatus, JournalStatus, AuditAction } from "@prisma/client";
import * as bcrypt from "bcryptjs";

config({ path: "../../.env" });

const prisma = new PrismaClient();

async function ensureDepartment(name: string, code: string) {
  return prisma.department.upsert({
    where: { code },
    update: { name, isActive: true },
    create: { name, code }
  });
}

async function ensurePosition(name: string) {
  const existing = await prisma.position.findFirst({ where: { name } });
  if (existing) {
    return prisma.position.update({
      where: { id: existing.id },
      data: { isActive: true }
    });
  }
  return prisma.position.create({ data: { name } });
}

async function ensureBriefingType(name: string, periodicityMonths: number) {
  const existing = await prisma.briefingType.findFirst({ where: { name } });
  if (existing) {
    return prisma.briefingType.update({
      where: { id: existing.id },
      data: { periodicityMonths, isActive: true }
    });
  }
  return prisma.briefingType.create({ data: { name, periodicityMonths } });
}

async function ensureUser(params: {
  email: string;
  fullName: string;
  role: Role;
  departmentId: string;
  positionId: string;
  passwordHash: string;
}) {
  return prisma.user.upsert({
    where: { email: params.email },
    update: {
      fullName: params.fullName,
      role: params.role,
      status: UserStatus.Active,
      departmentId: params.departmentId,
      positionId: params.positionId,
      passwordHash: params.passwordHash,
      isActive: true
    },
    create: {
      email: params.email,
      fullName: params.fullName,
      role: params.role,
      status: UserStatus.Active,
      hireDate: new Date("2026-01-10"),
      departmentId: params.departmentId,
      positionId: params.positionId,
      passwordHash: params.passwordHash
    }
  });
}

async function main() {
  const passwordHash = await bcrypt.hash("ChangeMe123!", 12);

  const [productionDept, safetyDept, warehouseDept] = await Promise.all([
    ensureDepartment("Производственный цех", "PRD"),
    ensureDepartment("Служба охраны труда", "SFT"),
    ensureDepartment("Склад", "WRH")
  ]);

  const [adminPosition, inspectorPosition, employeePosition] = await Promise.all([
    ensurePosition("Администратор"),
    ensurePosition("Инспектор ОТ"),
    ensurePosition("Оператор линии")
  ]);

  const [introType, primaryType, repeatType] = await Promise.all([
    ensureBriefingType("Вводный", 12),
    ensureBriefingType("Первичный", 6),
    ensureBriefingType("Повторный", 12)
  ]);

  const admin = await ensureUser({
    email: "admin@example.com",
    fullName: "Администратор Системы",
    role: Role.Admin,
    departmentId: safetyDept.id,
    positionId: adminPosition.id,
    passwordHash
  });

  const inspector = await ensureUser({
    email: "inspector@example.com",
    fullName: "Инспектор ОТ",
    role: Role.Inspector,
    departmentId: safetyDept.id,
    positionId: inspectorPosition.id,
    passwordHash
  });

  const employee = await ensureUser({
    email: "employee@example.com",
    fullName: "Сотрудник Производства",
    role: Role.Employee,
    departmentId: productionDept.id,
    positionId: employeePosition.id,
    passwordHash
  });

  const existingProgram = await prisma.briefingProgram.findFirst({
    where: { title: "Первичный инструктаж для производственного персонала" },
    include: { questions: true }
  });

  const program =
    existingProgram ??
    (await prisma.briefingProgram.create({
      data: {
        title: "Первичный инструктаж для производственного персонала",
        description: "Основные требования безопасности, СИЗ и порядок действий при инцидентах.",
        briefingTypeId: primaryType.id,
        status: ProgramStatus.Published,
        questions: {
          create: [
            { text: "Где расположен ближайший огнетушитель?", order: 1, isRequired: true },
            { text: "Какой номер вызова экстренных служб?", order: 2, isRequired: true }
          ]
        }
      },
      include: { questions: true }
    }));

  const existingJournal = await prisma.briefingJournal.findFirst({
    where: {
      programId: program.id,
      instructorId: inspector.id,
      departmentId: productionDept.id
    }
  });

  const journal =
    existingJournal ??
    (await prisma.briefingJournal.create({
      data: {
        programId: program.id,
        instructorId: inspector.id,
        departmentId: productionDept.id,
        briefingDate: new Date("2026-05-15"),
        status: JournalStatus.Completed
      }
    }));

  const existingRecord = await prisma.briefingRecord.findFirst({
    where: { journalId: journal.id, employeeId: employee.id }
  });

  if (!existingRecord) {
    await prisma.briefingRecord.create({
      data: {
        journalId: journal.id,
        employeeId: employee.id,
        signedAt: new Date("2026-05-15T09:15:00.000Z"),
        comment: "Инструктаж проведён, сотрудник ознакомлен."
      }
    });
  }

  const existingResult = await prisma.testResult.findFirst({
    where: { journalId: journal.id, employeeId: employee.id }
  });

  if (!existingResult) {
    const firstQuestionId = program.questions[0]?.id;
    const secondQuestionId = program.questions[1]?.id ?? firstQuestionId;
    if (!firstQuestionId || !secondQuestionId) {
      throw new Error("Не удалось найти вопросы программы для seed теста.");
    }

    await prisma.testResult.create({
      data: {
        journalId: journal.id,
        employeeId: employee.id,
        score: 90,
        status: TestResultStatus.Passed,
        answers: {
          create: [
            { questionId: firstQuestionId, employeeAnswer: "В коридоре у выхода", isCorrect: true },
            { questionId: secondQuestionId, employeeAnswer: "112", isCorrect: true }
          ]
        }
      }
    });
  }

  const hasAudit = await prisma.auditLog.findFirst({ where: { userId: admin.id, entityType: "Seed" } });
  if (!hasAudit) {
    await prisma.auditLog.create({
      data: {
        userId: admin.id,
        action: AuditAction.Create,
        entityType: "Seed",
        entityId: admin.id,
        ip: "127.0.0.1",
        metadata: { source: "prisma/seed.ts", seededAt: new Date().toISOString(), briefingTypes: [introType.name, primaryType.name, repeatType.name], departments: [productionDept.name, safetyDept.name, warehouseDept.name] }
      }
    });
  }

  console.log("Seed completed successfully.");
  console.log("Admin login: admin@example.com / ChangeMe123!");
  console.log("Inspector login: inspector@example.com / ChangeMe123!");
  console.log("Employee login: employee@example.com / ChangeMe123!");
}

main()
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
