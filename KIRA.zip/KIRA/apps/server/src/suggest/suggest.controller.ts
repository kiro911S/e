import { Controller, Get, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { SuggestService } from "./suggest.service";

@ApiTags("suggest")
@Controller("suggest")
export class SuggestController {
  constructor(private readonly suggestService: SuggestService) {}

  @Get("name")
  suggestName(@Query("query") query = "") {
    return this.suggestService.suggestName(query);
  }

  @Get("position")
  suggestPosition(@Query("query") query = "") {
    return this.suggestService.suggestPosition(query);
  }
}
