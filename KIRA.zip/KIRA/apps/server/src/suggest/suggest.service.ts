import { Injectable } from "@nestjs/common";

interface DaDataSuggestion {
  value: string;
}

interface DaDataResponse {
  suggestions: DaDataSuggestion[];
}

@Injectable()
export class SuggestService {
  private readonly baseUrl = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest";

  async suggestName(query: string): Promise<string[]> {
    return this.request("/fio", query);
  }

  async suggestPosition(query: string): Promise<string[]> {
    return this.request("/party", query);
  }

  private async request(endpoint: string, query: string): Promise<string[]> {
    if (!process.env.DADATA_API_KEY || query.length < 2) {
      return [];
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Token ${process.env.DADATA_API_KEY}`
      },
      body: JSON.stringify({ query, count: 5 })
    });

    if (!response.ok) {
      return [];
    }

    const payload = (await response.json()) as DaDataResponse;
    return payload.suggestions.map((item) => item.value);
  }
}
