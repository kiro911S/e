import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { APP_GUARD, APP_INTERCEPTOR } from "@nestjs/core";
import { ThrottlerModule } from "@nestjs/throttler";
import { AuthModule } from "./auth/auth.module";
import { JwtAuthGuard } from "./auth/guards/jwt-auth.guard";
import { RolesGuard } from "./auth/guards/roles.guard";
import { AuditInterceptor } from "./audit/audit.interceptor";
import { AuditModule } from "./audit/audit.module";
import { BriefingTypesModule } from "./briefing-types/briefing-types.module";
import { DepartmentsModule } from "./departments/departments.module";
import { JournalsModule } from "./journals/journals.module";
import { PositionsModule } from "./positions/positions.module";
import { PrismaModule } from "./prisma/prisma.module";
import { ProgramsModule } from "./programs/programs.module";
import { ReportsModule } from "./reports/reports.module";
import { RemindersModule } from "./reminders/reminders.module";
import { SuggestModule } from "./suggest/suggest.module";
import { TestModule } from "./test/test.module";
import { UsersModule } from "./users/users.module";

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ["../../.env", ".env"],
      ignoreEnvFile: false
    }),
    PrismaModule,
    ThrottlerModule.forRoot([
      {
        ttl: 60_000,
        limit: 120
      }
    ]),
    AuthModule,
    UsersModule,
    DepartmentsModule,
    PositionsModule,
    BriefingTypesModule,
    SuggestModule,
    ProgramsModule,
    JournalsModule,
    TestModule,
    ReportsModule,
    RemindersModule,
    AuditModule
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor }
  ]
})
export class AppModule {}
