import {
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { UserStatus } from "@ot/shared";
import { PrismaService } from "../prisma/prisma.service";
import { CreateUserDto } from "./dto/create-user.dto";
import { UpdateUserDto } from "./dto/update-user.dto";
import * as bcrypt from "bcryptjs";
import { UserResponseDto } from "./dto/user-response.dto";

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateUserDto): Promise<UserResponseDto> {
    const existing = await this.prisma.user.findUnique({
      where: { email: dto.email }
    });
    if (existing) {
      throw new ConflictException("Пользователь с таким email уже существует");
    }

    const passwordHash = await bcrypt.hash("ChangeMe123!", 12);
    const user = await this.prisma.user.create({
      data: {
        ...dto,
        hireDate: new Date(dto.hireDate),
        passwordHash
      }
    });
    return new UserResponseDto(user);
  }

  async findAll(): Promise<UserResponseDto[]> {
    const users = await this.prisma.user.findMany({
      where: { isActive: true },
      include: {
        department: true,
        position: true
      },
      orderBy: { createdAt: "desc" }
    });
    return users.map((user) => new UserResponseDto(user));
  }

  async findOne(id: string): Promise<UserResponseDto> {
    const user = await this.prisma.user.findFirst({
      where: { id, isActive: true },
      include: {
        department: true,
        position: true
      }
    });
    if (!user) {
      throw new NotFoundException("Пользователь не найден");
    }
    return new UserResponseDto(user);
  }

  async update(id: string, dto: UpdateUserDto): Promise<UserResponseDto> {
    await this.ensureUserExists(id);
    if (dto.email) {
      const existing = await this.prisma.user.findUnique({
        where: { email: dto.email }
      });
      if (existing && existing.id !== id) {
        throw new ConflictException("Пользователь с таким email уже существует");
      }
    }

    const user = await this.prisma.user.update({
      where: { id },
      data: {
        ...dto,
        hireDate: dto.hireDate ? new Date(dto.hireDate) : undefined
      }
    });
    return new UserResponseDto(user);
  }

  async toggleStatus(id: string, isActive: boolean): Promise<UserResponseDto> {
    await this.ensureUserExists(id);
    const user = await this.prisma.user.update({
      where: { id },
      data: {
        isActive,
        status: isActive ? UserStatus.Active : UserStatus.Inactive
      }
    });
    return new UserResponseDto(user);
  }

  async resetPassword(id: string, nextPassword?: string): Promise<{ temporaryPassword: string }> {
    await this.ensureUserExists(id);
    const temporaryPassword = nextPassword && nextPassword.trim().length >= 8
      ? nextPassword
      : this.generateTemporaryPassword();
    const passwordHash = await bcrypt.hash(temporaryPassword, 12);
    await this.prisma.user.update({
      where: { id },
      data: { passwordHash }
    });
    return { temporaryPassword };
  }

  async remove(id: string): Promise<{ success: boolean }> {
    await this.ensureUserExists(id);
    await this.prisma.user.update({
      where: { id },
      data: {
        isActive: false,
        status: UserStatus.Inactive
      }
    });
    return { success: true };
  }

  private async ensureUserExists(id: string): Promise<void> {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: { id: true, isActive: true }
    });
    if (!user || !user.isActive) {
      throw new NotFoundException("Пользователь не найден");
    }
  }

  private generateTemporaryPassword(): string {
    const salt = Math.random().toString(36).slice(2, 8);
    return `Temp#${salt}9A`;
  }
}
