import { Role, UserStatus } from "@ot/shared";
import { IsDateString, IsEmail, IsEnum, IsUUID, Length } from "class-validator";

export class CreateUserDto {
  @Length(2, 255)
  fullName!: string;

  @IsEmail()
  email!: string;

  @IsEnum(Role)
  role!: Role;

  @IsUUID()
  departmentId!: string;

  @IsUUID()
  positionId!: string;

  @IsDateString()
  hireDate!: string;

  @IsEnum(UserStatus)
  status!: UserStatus;
}
