import { Exclude } from "class-transformer";

export class UserResponseDto {
  id!: string;
  fullName!: string;
  email!: string;
  role!: string;
  status!: string;
  departmentId!: string;
  positionId!: string;
  hireDate!: Date;
  isActive!: boolean;

  @Exclude()
  passwordHash!: string;

  constructor(partial: Partial<UserResponseDto>) {
    Object.assign(this, partial);
  }
}
