import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseBoolPipe,
  Patch,
  Post,
  Query
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Role } from "@ot/shared";
import { Roles } from "../auth/decorators/roles.decorator";
import { CreateUserDto } from "./dto/create-user.dto";
import { UpdateUserDto } from "./dto/update-user.dto";
import { UsersService } from "./users.service";

@ApiTags("users")
@Controller("users")
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  @Roles(Role.Admin, Role.Inspector)
  findAll() {
    return this.usersService.findAll();
  }

  @Get(":id")
  @Roles(Role.Admin, Role.Inspector)
  findOne(@Param("id") id: string) {
    return this.usersService.findOne(id);
  }

  @Post()
  @Roles(Role.Admin)
  create(@Body() dto: CreateUserDto) {
    return this.usersService.create(dto);
  }

  @Patch(":id")
  @Roles(Role.Admin)
  update(@Param("id") id: string, @Body() dto: UpdateUserDto) {
    return this.usersService.update(id, dto);
  }

  @Patch(":id/status")
  @Roles(Role.Admin)
  toggleStatus(
    @Param("id") id: string,
    @Query("isActive", new ParseBoolPipe({ optional: true })) isActive?: boolean
  ) {
    return this.usersService.toggleStatus(id, isActive ?? true);
  }

  @Post(":id/reset-password")
  @Roles(Role.Admin)
  resetPassword(
    @Param("id") id: string,
    @Body() body: { password?: string }
  ) {
    return this.usersService.resetPassword(id, body.password);
  }

  @Delete(":id")
  @Roles(Role.Admin)
  remove(@Param("id") id: string) {
    return this.usersService.remove(id);
  }
}
