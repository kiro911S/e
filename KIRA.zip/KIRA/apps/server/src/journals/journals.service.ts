import {
  ForbiddenException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { Role } from "@ot/shared";
import { PrismaService } from "../prisma/prisma.service";
import { CreateJournalDto } from "./dto/create-journal.dto";
import { CreateJournalRecordDto } from "./dto/create-journal-record.dto";
import { UpdateJournalDto } from "./dto/update-journal.dto";
import { UpdateJournalRecordDto } from "./dto/update-journal-record.dto";

@Injectable()
export class JournalsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.briefingJournal.findMany({
      where: { isActive: true },
      include: {
        program: true,
        department: true,
        instructor: true,
        records: {
          include: {
            employee: true
          }
        }
      },
      orderBy: {
        briefingDate: "desc"
      }
    });
  }

  async findOne(id: string) {
    const journal = await this.prisma.briefingJournal.findFirst({
      where: { id, isActive: true },
      include: {
        program: {
          include: {
            questions: true
          }
        },
        department: true,
        instructor: true,
        records: {
          include: {
            employee: true
          }
        },
        testResults: true
      }
    });
    if (!journal) {
      throw new NotFoundException("Журнал не найден");
    }
    return journal;
  }

  create(dto: CreateJournalDto) {
    return this.prisma.briefingJournal.create({
      data: {
        ...dto,
        briefingDate: new Date(dto.briefingDate)
      }
    });
  }

  async update(id: string, dto: UpdateJournalDto) {
    await this.findOne(id);
    return this.prisma.briefingJournal.update({
      where: { id },
      data: {
        ...dto,
        briefingDate: dto.briefingDate ? new Date(dto.briefingDate) : undefined
      }
    });
  }

  async listRecords(journalId: string) {
    await this.findOne(journalId);
    return this.prisma.briefingRecord.findMany({
      where: { journalId },
      include: { employee: true },
      orderBy: { createdAt: "desc" }
    });
  }

  async createRecord(journalId: string, dto: CreateJournalRecordDto) {
    await this.findOne(journalId);
    return this.prisma.briefingRecord.create({
      data: {
        journalId,
        employeeId: dto.employeeId,
        signedAt: dto.signedAt ? new Date(dto.signedAt) : undefined,
        comment: dto.comment
      }
    });
  }

  async updateRecord(recordId: string, dto: UpdateJournalRecordDto) {
    const record = await this.prisma.briefingRecord.findUnique({
      where: { id: recordId }
    });
    if (!record) {
      throw new NotFoundException("Запись инструктажа не найдена");
    }
    return this.prisma.briefingRecord.update({
      where: { id: recordId },
      data: {
        employeeId: dto.employeeId,
        signedAt: dto.signedAt ? new Date(dto.signedAt) : undefined,
        comment: dto.comment
      }
    });
  }

  async getMyBriefings(userId: string, role: Role) {
    if (role !== Role.Employee) {
      throw new ForbiddenException("Раздел доступен только для сотрудника");
    }
    return this.prisma.briefingRecord.findMany({
      where: {
        employeeId: userId,
        journal: {
          isActive: true
        }
      },
      include: {
        journal: {
          include: {
            program: {
              include: {
                briefingType: true
              }
            }
          }
        },
        employee: true
      },
      orderBy: {
        journal: {
          briefingDate: "desc"
        }
      }
    });
  }
}
