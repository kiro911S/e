import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Role } from "@ot/shared";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { Roles } from "../auth/decorators/roles.decorator";
import type { JwtAuthUser } from "../auth/auth.service";
import { CreateJournalDto } from "./dto/create-journal.dto";
import { CreateJournalRecordDto } from "./dto/create-journal-record.dto";
import { UpdateJournalDto } from "./dto/update-journal.dto";
import { UpdateJournalRecordDto } from "./dto/update-journal-record.dto";
import { JournalsService } from "./journals.service";

@ApiTags("journals")
@Controller("journals")
export class JournalsController {
  constructor(private readonly journalsService: JournalsService) {}

  @Get()
  findAll() {
    return this.journalsService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.journalsService.findOne(id);
  }

  @Post()
  @Roles(Role.Admin, Role.Inspector)
  create(@Body() dto: CreateJournalDto) {
    return this.journalsService.create(dto);
  }

  @Patch(":id")
  @Roles(Role.Admin, Role.Inspector)
  update(@Param("id") id: string, @Body() dto: UpdateJournalDto) {
    return this.journalsService.update(id, dto);
  }

  @Get(":id/records")
  @Roles(Role.Admin, Role.Inspector)
  records(@Param("id") id: string) {
    return this.journalsService.listRecords(id);
  }

  @Post(":id/records")
  @Roles(Role.Admin, Role.Inspector)
  createRecord(@Param("id") id: string, @Body() dto: CreateJournalRecordDto) {
    return this.journalsService.createRecord(id, dto);
  }

  @Patch("records/:recordId")
  @Roles(Role.Admin, Role.Inspector)
  updateRecord(
    @Param("recordId") recordId: string,
    @Body() dto: UpdateJournalRecordDto
  ) {
    return this.journalsService.updateRecord(recordId, dto);
  }

  @Get("me/briefings")
  getMyBriefings(@CurrentUser() user: JwtAuthUser) {
    return this.journalsService.getMyBriefings(user.sub, user.role);
  }
}
