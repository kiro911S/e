import {
  IsDateString,
  IsOptional,
  IsString,
  IsUUID,
  Length
} from "class-validator";

export class CreateJournalRecordDto {
  @IsUUID()
  employeeId!: string;

  @IsOptional()
  @IsDateString()
  signedAt?: string;

  @IsOptional()
  @IsString()
  @Length(0, 500)
  comment?: string;
}
