import { PartialType } from "@nestjs/swagger";
import { CreateJournalRecordDto } from "./create-journal-record.dto";

export class UpdateJournalRecordDto extends PartialType(CreateJournalRecordDto) {}
