import { JournalStatus } from "@ot/shared";
import { IsDateString, IsEnum, IsUUID } from "class-validator";

export class CreateJournalDto {
  @IsUUID()
  programId!: string;

  @IsDateString()
  briefingDate!: string;

  @IsUUID()
  instructorId!: string;

  @IsUUID()
  departmentId!: string;

  @IsEnum(JournalStatus)
  status!: JournalStatus;
}
