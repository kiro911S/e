import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor
} from "@nestjs/common";
import { AuditAction } from "@ot/shared";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { PrismaService } from "../prisma/prisma.service";

interface RequestUser {
  sub?: string;
}

interface RequestLike {
  method: string;
  ip?: string;
  originalUrl?: string;
  body?: Record<string, unknown>;
  params?: Record<string, string>;
  user?: RequestUser;
}

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(private readonly prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<RequestLike>();
    const handlerName = context.getHandler().name;
    const controllerName = context.getClass().name.replace("Controller", "");
    const method = request.method.toUpperCase();
    const isMutating = ["POST", "PUT", "PATCH", "DELETE"].includes(method);

    return next.handle().pipe(
      tap({
        next: async (responseData: unknown) => {
          if (!isMutating) {
            return;
          }
          const actionMap: Record<string, AuditAction> = {
            POST: AuditAction.Create,
            PUT: AuditAction.Update,
            PATCH: AuditAction.Update,
            DELETE: AuditAction.Delete
          };

          const responseEntityId =
            typeof responseData === "object" &&
            responseData !== null &&
            "id" in responseData
              ? String(
                  (responseData as { id?: unknown }).id ??
                    request.params?.id ??
                    "n/a"
                )
              : request.params?.id ?? "n/a";

          await this.prisma.auditLog.create({
            data: {
              userId: request.user?.sub,
              action: actionMap[method] ?? AuditAction.Update,
              entityType: controllerName || request.originalUrl || "unknown",
              entityId: responseEntityId,
              ip: request.ip,
              metadata: {
                route: request.originalUrl,
                handlerName,
                method,
                params: request.params,
                payloadKeys: Object.keys(request.body ?? {})
              }
            }
          });
        }
      })
    );
  }
}
