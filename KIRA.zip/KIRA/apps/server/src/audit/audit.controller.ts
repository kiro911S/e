import { Controller, Get, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Roles } from "../auth/decorators/roles.decorator";
import { Role } from "@ot/shared";
import { AuditService } from "./audit.service";

@ApiTags("audit")
@Controller("audit")
export class AuditController {
  constructor(private readonly auditService: AuditService) {}

  @Get()
  @Roles(Role.Admin, Role.Inspector)
  findLatest(@Query("limit") limit?: string) {
    const safeLimit = Number(limit ?? "20");
    return this.auditService.findLatest(Number.isNaN(safeLimit) ? 20 : safeLimit);
  }
}
