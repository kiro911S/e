import {
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CreateDepartmentDto } from "./dto/create-department.dto";
import { UpdateDepartmentDto } from "./dto/update-department.dto";

@Injectable()
export class DepartmentsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.department.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" }
    });
  }

  async findOne(id: string) {
    const department = await this.prisma.department.findFirst({
      where: { id, isActive: true }
    });
    if (!department) {
      throw new NotFoundException("Подразделение не найдено");
    }
    return department;
  }

  async create(dto: CreateDepartmentDto) {
    const exists = await this.prisma.department.findUnique({
      where: { code: dto.code }
    });
    if (exists) {
      throw new ConflictException("Подразделение с таким кодом уже существует");
    }
    return this.prisma.department.create({ data: dto });
  }

  async update(id: string, dto: UpdateDepartmentDto) {
    await this.findOne(id);
    return this.prisma.department.update({
      where: { id },
      data: dto
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.department.update({
      where: { id },
      data: { isActive: false }
    });
    return { success: true };
  }
}
