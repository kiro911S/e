import { IsString, Length } from "class-validator";

export class CreateDepartmentDto {
  @IsString()
  @Length(2, 255)
  name!: string;

  @IsString()
  @Length(1, 32)
  code!: string;
}
