import {
  Body,
  Controller,
  Get,
  Post,
  Req,
  Res,
  UnauthorizedException
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { Throttle } from "@nestjs/throttler";
import type { Request, Response } from "express";
import { CurrentUser } from "./decorators/current-user.decorator";
import { Public } from "./decorators/public.decorator";
import { LoginDto } from "./dto/login.dto";
import { AuthService, type JwtAuthUser } from "./auth.service";

const REFRESH_COOKIE_NAME = "ot_refresh_token";

@ApiTags("auth")
@Controller("auth")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post("login")
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiOperation({ summary: "Вход пользователя" })
  async login(@Body() dto: LoginDto, @Res({ passthrough: true }) response: Response) {
    const result = await this.authService.login(dto);
    this.setRefreshCookie(response, result.refreshToken);
    return {
      accessToken: result.accessToken,
      user: result.user
    };
  }

  @Public()
  @Post("refresh")
  @ApiOperation({ summary: "Обновление access token по refresh cookie" })
  async refresh(
    @Req() request: Request,
    @Res({ passthrough: true }) response: Response
  ) {
    const refreshToken = request.cookies?.[REFRESH_COOKIE_NAME] as string | undefined;
    if (!refreshToken) {
      throw new UnauthorizedException("Сессия не найдена");
    }
    const result = await this.authService.refresh(refreshToken);
    this.setRefreshCookie(response, result.refreshToken);
    return {
      accessToken: result.accessToken,
      user: result.user
    };
  }

  @Post("logout")
  @Public()
  @ApiOperation({ summary: "Выход пользователя" })
  logout(@Res({ passthrough: true }) response: Response) {
    response.clearCookie(REFRESH_COOKIE_NAME, this.buildRefreshCookieOptions());
    return { success: true };
  }

  @Get("me")
  @ApiOperation({ summary: "Текущий авторизованный пользователь" })
  me(@CurrentUser() user: JwtAuthUser) {
    return this.authService.me(user.sub);
  }

  private setRefreshCookie(response: Response, refreshToken: string): void {
    response.cookie(
      REFRESH_COOKIE_NAME,
      refreshToken,
      this.buildRefreshCookieOptions()
    );
  }

  private buildRefreshCookieOptions() {
    const maxAgeMs = 7 * 24 * 60 * 60 * 1000;
    return {
      httpOnly: true,
      sameSite: "lax" as const,
      secure: process.env.NODE_ENV === "production",
      path: "/api/v1/auth",
      maxAge: maxAgeMs
    };
  }
}
