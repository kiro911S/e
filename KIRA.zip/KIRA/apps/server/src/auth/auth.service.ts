import {
  ForbiddenException,
  Injectable,
  UnauthorizedException
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { Role } from "@ot/shared";
import * as bcrypt from "bcryptjs";
import { PrismaService } from "../prisma/prisma.service";
import { LoginDto } from "./dto/login.dto";

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    fullName: string;
    email: string;
    role: Role;
  };
}

export interface JwtAuthUser {
  sub: string;
  role: Role;
}

interface AuthenticatedUser {
  id: string;
  fullName: string;
  email: string;
  role: Role;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService
  ) {}

  async login(dto: LoginDto): Promise<LoginResponse> {
    const user = await this.validateUser(dto.email, dto.password);
    return this.issueTokens({
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      role: user.role as Role
    });
  }

  async refresh(refreshToken: string): Promise<LoginResponse> {
    const payload = await this.verifyRefreshToken(refreshToken);
    const user = await this.prisma.user.findUnique({
      where: { id: payload.sub }
    });
    if (!user || !user.isActive) {
      throw new UnauthorizedException("Сессия недействительна");
    }
    return this.issueTokens({
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      role: user.role as Role
    });
  }

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        fullName: true,
        email: true,
        role: true,
        status: true,
        departmentId: true,
        positionId: true
      }
    });
    if (!user) {
      throw new UnauthorizedException("Пользователь не найден");
    }
    return user;
  }

  private async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({
      where: { email }
    });
    if (!user || !user.isActive) {
      throw new UnauthorizedException("Неверный email или пароль");
    }

    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      throw new UnauthorizedException("Неверный email или пароль");
    }
    return user;
  }

  private async issueTokens(user: AuthenticatedUser): Promise<LoginResponse> {
    const accessToken = await this.jwtService.signAsync(
      { sub: user.id, role: user.role },
      { expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? "15m" }
    );
    const refreshToken = await this.jwtService.signAsync(
      { sub: user.id, role: user.role },
      {
        secret: process.env.JWT_REFRESH_SECRET ?? "dev-refresh-secret",
        expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? "7d"
      }
    );

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        role: user.role
      }
    };
  }

  private async verifyRefreshToken(token: string): Promise<JwtAuthUser> {
    try {
      const payload = await this.jwtService.verifyAsync<JwtAuthUser>(token, {
        secret: process.env.JWT_REFRESH_SECRET ?? "dev-refresh-secret"
      });
      return payload;
    } catch {
      throw new ForbiddenException("Срок сессии истёк. Выполните вход заново.");
    }
  }
}
