import { createParamDecorator, ExecutionContext } from "@nestjs/common";

interface JwtUser {
  sub: string;
  role: string;
}

export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext): JwtUser | undefined => {
  const request = ctx.switchToHttp().getRequest<{ user?: JwtUser }>();
  return request.user;
});
