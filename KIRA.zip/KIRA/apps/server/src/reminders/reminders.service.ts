import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class RemindersService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RemindersService.name);
  private timer: NodeJS.Timeout | null = null;

  constructor(private readonly prisma: PrismaService) {}

  onModuleInit(): void {
    this.timer = setInterval(() => {
      void this.runReminderTick();
    }, 10 * 60 * 1000);
    void this.runReminderTick();
  }

  onModuleDestroy(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private async runReminderTick(): Promise<void> {
    const now = new Date();
    const nextWeek = new Date(now);
    nextWeek.setDate(nextWeek.getDate() + 7);

    const [upcoming, overdue] = await this.prisma.$transaction([
      this.prisma.briefingJournal.count({
        where: {
          isActive: true,
          briefingDate: {
            gte: now,
            lte: nextWeek
          }
        }
      }),
      this.prisma.briefingJournal.count({
        where: {
          isActive: true,
          briefingDate: {
            lt: now
          }
        }
      })
    ]);

    this.logger.log(
      `Reminder tick: upcoming=${upcoming}, overdue=${overdue}. Provider adapter is not configured, running in safe log-only mode.`
    );
  }
}
