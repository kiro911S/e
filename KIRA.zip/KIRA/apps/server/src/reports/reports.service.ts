import { Injectable } from "@nestjs/common";
import { JournalStatus } from "@ot/shared";
import { PrismaService } from "../prisma/prisma.service";

@Injectable()
export class ReportsService {
  constructor(private readonly prisma: PrismaService) {}

  async completionReport(from: string, to: string) {
    const dateFrom = new Date(from);
    const dateTo = new Date(to);

    const testResults = await this.prisma.testResult.findMany({
      where: {
        createdAt: {
          gte: dateFrom,
          lte: dateTo
        }
      },
      include: {
        employee: {
          include: {
            department: true
          }
        }
      }
    });

    const grouped = new Map<string, { departmentName: string; completed: number; failed: number }>();

    testResults.forEach((result) => {
      const departmentName = result.employee.department.name;
      const current = grouped.get(departmentName) ?? {
        departmentName,
        completed: 0,
        failed: 0
      };
      if (result.status === "Passed") {
        current.completed += 1;
      } else {
        current.failed += 1;
      }
      grouped.set(departmentName, current);
    });

    return Array.from(grouped.values()).map((item) => ({
      ...item,
      totalEmployees: item.completed + item.failed
    }));
  }

  async summary() {
    const [users, journals, programs, tests] = await this.prisma.$transaction([
      this.prisma.user.count({ where: { isActive: true } }),
      this.prisma.briefingJournal.count({ where: { isActive: true } }),
      this.prisma.briefingProgram.count({ where: { isActive: true } }),
      this.prisma.testResult.count()
    ]);
    return { users, journals, programs, tests };
  }

  async upcoming(days = 14) {
    const now = new Date();
    const end = new Date(now);
    end.setDate(end.getDate() + days);
    return this.prisma.briefingJournal.findMany({
      where: {
        isActive: true,
        briefingDate: {
          gte: now,
          lte: end
        }
      },
      include: {
        program: true,
        department: true
      },
      orderBy: {
        briefingDate: "asc"
      }
    });
  }

  async overdue() {
    const now = new Date();
    return this.prisma.briefingJournal.findMany({
      where: {
        isActive: true,
        briefingDate: {
          lt: now
        },
        status: {
          not: JournalStatus.Completed
        }
      },
      include: {
        program: true,
        department: true
      },
      orderBy: {
        briefingDate: "asc"
      }
    });
  }

  async employeeHistory(employeeId: string) {
    const records = await this.prisma.briefingRecord.findMany({
      where: { employeeId },
      include: {
        journal: {
          include: {
            program: {
              include: {
                briefingType: true
              }
            }
          }
        },
        employee: true
      },
      orderBy: {
        journal: {
          briefingDate: "desc"
        }
      }
    });

    const testResults = await this.prisma.testResult.findMany({
      where: { employeeId },
      orderBy: { createdAt: "desc" }
    });

    return {
      records,
      testResults
    };
  }
}
