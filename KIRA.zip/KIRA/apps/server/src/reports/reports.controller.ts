import { Controller, Get, Query } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Role } from "@ot/shared";
import { Roles } from "../auth/decorators/roles.decorator";
import { ReportsService } from "./reports.service";

@ApiTags("reports")
@Controller("reports")
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get("completion")
  @Roles(Role.Admin, Role.Inspector)
  completion(@Query("from") from: string, @Query("to") to: string) {
    return this.reportsService.completionReport(from, to);
  }

  @Get("summary")
  summary() {
    return this.reportsService.summary();
  }

  @Get("upcoming")
  upcoming(@Query("days") days?: string) {
    const parsed = Number(days ?? "14");
    return this.reportsService.upcoming(Number.isNaN(parsed) ? 14 : parsed);
  }

  @Get("overdue")
  overdue() {
    return this.reportsService.overdue();
  }

  @Get("employee-history")
  employeeHistory(@Query("employeeId") employeeId: string) {
    return this.reportsService.employeeHistory(employeeId);
  }
}
