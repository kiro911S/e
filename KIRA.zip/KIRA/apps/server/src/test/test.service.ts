import {
  ForbiddenException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { Role, TestResultStatus } from "@ot/shared";
import { PrismaService } from "../prisma/prisma.service";
import { SubmitTestDto } from "./dto/submit-test.dto";

@Injectable()
export class TestService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.testResult.findMany({
      include: { answers: true, employee: true, journal: true }
    });
  }

  async getQuestionsByJournal(
    journalId: string,
    employeeId: string,
    role: Role
  ) {
    if (role !== Role.Employee) {
      throw new ForbiddenException("Тестирование доступно только сотруднику");
    }
    await this.ensureEmployeeHasAccess(journalId, employeeId);
    const journal = await this.prisma.briefingJournal.findFirst({
      where: { id: journalId, isActive: true },
      include: {
        program: {
          include: {
            questions: {
              orderBy: { order: "asc" }
            }
          }
        }
      }
    });
    if (!journal) {
      throw new NotFoundException("Журнал не найден");
    }
    return {
      journalId: journal.id,
      programId: journal.programId,
      programTitle: journal.program.title,
      questions: journal.program.questions
    };
  }

  async submit(dto: SubmitTestDto, employeeId: string, role: Role) {
    if (role !== Role.Employee) {
      throw new ForbiddenException("Отправка теста доступна только сотруднику");
    }
    const journal = await this.ensureEmployeeHasAccess(dto.journalId, employeeId);
    const allQuestions = journal.program.questions;
    if (allQuestions.length === 0) {
      throw new NotFoundException("Для программы не найдены вопросы");
    }

    const requiredQuestions = allQuestions.filter((question) => question.isRequired);
    const answersMap = new Map(
      dto.answers.map((answer) => [answer.questionId, answer.answer.trim()])
    );

    let correctRequired = 0;
    for (const question of requiredQuestions) {
      const answer = answersMap.get(question.id);
      if (answer && answer.length > 0) {
        correctRequired += 1;
      }
    }

    const denominator = requiredQuestions.length || allQuestions.length;
    const score = denominator > 0 ? Math.round((correctRequired / denominator) * 100) : 0;
    const status =
      score >= 80 ? TestResultStatus.Passed : TestResultStatus.Failed;

    return this.prisma.testResult.create({
      data: {
        journalId: dto.journalId,
        employeeId,
        score,
        status,
        answers: {
          create: dto.answers.map((answer) => ({
            questionId: answer.questionId,
            employeeAnswer: answer.answer,
            isCorrect:
              (answersMap.get(answer.questionId)?.length ?? 0) > 0
          }))
        }
      },
      include: { answers: true }
    });
  }

  private async ensureEmployeeHasAccess(journalId: string, employeeId: string) {
    const journal = await this.prisma.briefingJournal.findFirst({
      where: { id: journalId, isActive: true },
      include: {
        records: {
          where: { employeeId }
        },
        program: {
          include: {
            questions: true
          }
        }
      }
    });
    if (!journal) {
      throw new NotFoundException("Журнал не найден");
    }
    if (journal.records.length === 0) {
      throw new ForbiddenException("Сотрудник не назначен в этот журнал");
    }
    return journal;
  }
}
