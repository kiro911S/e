import { Body, Controller, Get, Param, Post } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import type { JwtAuthUser } from "../auth/auth.service";
import { CurrentUser } from "../auth/decorators/current-user.decorator";
import { SubmitTestDto } from "./dto/submit-test.dto";
import { TestService } from "./test.service";

@ApiTags("test")
@Controller("test")
export class TestController {
  constructor(private readonly testService: TestService) {}

  @Get("results")
  findAll() {
    return this.testService.findAll();
  }

  @Get("journals/:journalId/questions")
  getQuestions(
    @Param("journalId") journalId: string,
    @CurrentUser() user: JwtAuthUser
  ) {
    return this.testService.getQuestionsByJournal(journalId, user.sub, user.role);
  }

  @Post("submit")
  submit(@Body() dto: SubmitTestDto, @CurrentUser() user: JwtAuthUser) {
    return this.testService.submit(dto, user.sub, user.role);
  }
}
