import {
  ArrayMinSize,
  IsArray,
  IsString,
  IsUUID,
  ValidateNested
} from "class-validator";
import { Type } from "class-transformer";

class TestAnswerDto {
  @IsUUID()
  questionId!: string;

  @IsString()
  answer!: string;
}

export class SubmitTestDto {
  @IsUUID()
  journalId!: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => TestAnswerDto)
  answers!: TestAnswerDto[];
}
