import { Module } from "@nestjs/common";
import { BriefingTypesController } from "./briefing-types.controller";
import { BriefingTypesService } from "./briefing-types.service";

@Module({
  controllers: [BriefingTypesController],
  providers: [BriefingTypesService]
})
export class BriefingTypesModule {}
