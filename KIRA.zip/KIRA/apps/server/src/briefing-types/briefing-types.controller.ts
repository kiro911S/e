import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Role } from "@ot/shared";
import { Roles } from "../auth/decorators/roles.decorator";
import { CreateBriefingTypeDto } from "./dto/create-briefing-type.dto";
import { UpdateBriefingTypeDto } from "./dto/update-briefing-type.dto";
import { BriefingTypesService } from "./briefing-types.service";

@ApiTags("briefing-types")
@Controller("briefing-types")
export class BriefingTypesController {
  constructor(private readonly briefingTypesService: BriefingTypesService) {}

  @Get()
  findAll() {
    return this.briefingTypesService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.briefingTypesService.findOne(id);
  }

  @Post()
  @Roles(Role.Admin)
  create(@Body() dto: CreateBriefingTypeDto) {
    return this.briefingTypesService.create(dto);
  }

  @Patch(":id")
  @Roles(Role.Admin)
  update(@Param("id") id: string, @Body() dto: UpdateBriefingTypeDto) {
    return this.briefingTypesService.update(id, dto);
  }

  @Delete(":id")
  @Roles(Role.Admin)
  remove(@Param("id") id: string) {
    return this.briefingTypesService.remove(id);
  }
}
