import {
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CreateBriefingTypeDto } from "./dto/create-briefing-type.dto";
import { UpdateBriefingTypeDto } from "./dto/update-briefing-type.dto";

@Injectable()
export class BriefingTypesService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.briefingType.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" }
    });
  }

  async findOne(id: string) {
    const briefingType = await this.prisma.briefingType.findFirst({
      where: { id, isActive: true }
    });
    if (!briefingType) {
      throw new NotFoundException("Вид инструктажа не найден");
    }
    return briefingType;
  }

  async create(dto: CreateBriefingTypeDto) {
    const exists = await this.prisma.briefingType.findFirst({
      where: { name: dto.name, isActive: true }
    });
    if (exists) {
      throw new ConflictException("Вид инструктажа уже существует");
    }
    return this.prisma.briefingType.create({ data: dto });
  }

  async update(id: string, dto: UpdateBriefingTypeDto) {
    await this.findOne(id);
    return this.prisma.briefingType.update({
      where: { id },
      data: dto
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.briefingType.update({
      where: { id },
      data: { isActive: false }
    });
    return { success: true };
  }
}
