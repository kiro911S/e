import { PartialType } from "@nestjs/swagger";
import { CreateBriefingTypeDto } from "./create-briefing-type.dto";

export class UpdateBriefingTypeDto extends PartialType(CreateBriefingTypeDto) {}
