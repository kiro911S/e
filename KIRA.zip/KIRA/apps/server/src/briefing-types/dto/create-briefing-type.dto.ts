import { IsInt, IsString, Length, Max, Min } from "class-validator";

export class CreateBriefingTypeDto {
  @IsString()
  @Length(2, 255)
  name!: string;

  @IsInt()
  @Min(1)
  @Max(36)
  periodicityMonths!: number;
}
