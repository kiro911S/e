import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Role } from "@ot/shared";
import { Roles } from "../auth/decorators/roles.decorator";
import { CreatePositionDto } from "./dto/create-position.dto";
import { UpdatePositionDto } from "./dto/update-position.dto";
import { PositionsService } from "./positions.service";

@ApiTags("positions")
@Controller("positions")
export class PositionsController {
  constructor(private readonly positionsService: PositionsService) {}

  @Get()
  findAll() {
    return this.positionsService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.positionsService.findOne(id);
  }

  @Post()
  @Roles(Role.Admin)
  create(@Body() dto: CreatePositionDto) {
    return this.positionsService.create(dto);
  }

  @Patch(":id")
  @Roles(Role.Admin)
  update(@Param("id") id: string, @Body() dto: UpdatePositionDto) {
    return this.positionsService.update(id, dto);
  }

  @Delete(":id")
  @Roles(Role.Admin)
  remove(@Param("id") id: string) {
    return this.positionsService.remove(id);
  }
}
