import {
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { CreatePositionDto } from "./dto/create-position.dto";
import { UpdatePositionDto } from "./dto/update-position.dto";

@Injectable()
export class PositionsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.position.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" }
    });
  }

  async findOne(id: string) {
    const position = await this.prisma.position.findFirst({
      where: { id, isActive: true }
    });
    if (!position) {
      throw new NotFoundException("Должность не найдена");
    }
    return position;
  }

  async create(dto: CreatePositionDto) {
    const exists = await this.prisma.position.findFirst({
      where: { name: dto.name, isActive: true }
    });
    if (exists) {
      throw new ConflictException("Должность уже существует");
    }
    return this.prisma.position.create({ data: dto });
  }

  async update(id: string, dto: UpdatePositionDto) {
    await this.findOne(id);
    return this.prisma.position.update({
      where: { id },
      data: dto
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.position.update({
      where: { id },
      data: { isActive: false }
    });
    return { success: true };
  }
}
