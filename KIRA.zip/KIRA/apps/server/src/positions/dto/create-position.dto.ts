import { IsString, Length } from "class-validator";

export class CreatePositionDto {
  @IsString()
  @Length(2, 255)
  name!: string;
}
