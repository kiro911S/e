import { ProgramStatus } from "@ot/shared";
import {
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  ValidateNested
} from "class-validator";
import { Type } from "class-transformer";

class ProgramQuestionDto {
  @IsString()
  @Length(3, 1000)
  text!: string;

  @IsInt()
  order!: number;

  @IsBoolean()
  isRequired!: boolean;
}

export class CreateProgramDto {
  @IsString()
  @Length(3, 255)
  title!: string;

  @IsOptional()
  @IsString()
  @Length(0, 2000)
  description?: string;

  @IsUUID()
  briefingTypeId!: string;

  @IsEnum(ProgramStatus)
  status!: ProgramStatus;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => ProgramQuestionDto)
  questions!: ProgramQuestionDto[];
}
