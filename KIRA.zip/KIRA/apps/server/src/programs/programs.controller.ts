import {
  Body,
  Controller,
  Delete,
  BadRequestException,
  Get,
  NotFoundException,
  Param,
  ParseEnumPipe,
  Patch,
  Post,
  Res,
  UploadedFile,
  UseInterceptors
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { ProgramStatus, Role } from "@ot/shared";
import { FileInterceptor } from "@nestjs/platform-express";
import type { Response } from "express";
import { promises as fs } from "fs";
import { Roles } from "../auth/decorators/roles.decorator";
import { CreateProgramDto } from "./dto/create-program.dto";
import { UpdateProgramDto } from "./dto/update-program.dto";
import { ProgramsService } from "./programs.service";

@ApiTags("programs")
@Controller("programs")
export class ProgramsController {
  constructor(private readonly programsService: ProgramsService) {}

  @Get()
  findAll() {
    return this.programsService.findAll();
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.programsService.findOne(id);
  }

  @Get(":id/questions")
  questions(@Param("id") id: string) {
    return this.programsService.listQuestions(id);
  }

  @Get(":id/document")
  document(@Param("id") id: string) {
    return this.programsService.getProgramDocument(id);
  }

  @Get(":id/document/download")
  async downloadDocument(
    @Param("id") id: string,
    @Res() response: Response
  ) {
    const filePath = this.programsService.getProgramDocumentPath(id);
    try {
      await fs.access(filePath);
    } catch {
      throw new NotFoundException("PDF-файл программы не найден");
    }
    response.setHeader("Content-Type", "application/pdf");
    response.sendFile(filePath);
  }

  @Post()
  @Roles(Role.Admin)
  create(@Body() dto: CreateProgramDto) {
    return this.programsService.create(dto);
  }

  @Post(":id/upload-pdf")
  @Roles(Role.Admin)
  @UseInterceptors(
    FileInterceptor("file", {
      limits: {
        fileSize: 10 * 1024 * 1024
      }
    })
  )
  uploadPdf(
    @Param("id") id: string,
    @UploadedFile() file: Express.Multer.File
  ) {
    if (!file) {
      throw new BadRequestException("Файл не передан");
    }
    if (file.mimetype !== "application/pdf") {
      throw new BadRequestException("Допустим только PDF-файл");
    }
    return this.programsService.saveProgramDocument(id, file);
  }

  @Patch(":id")
  @Roles(Role.Admin)
  update(@Param("id") id: string, @Body() dto: UpdateProgramDto) {
    return this.programsService.update(id, dto);
  }

  @Patch(":id/status/:status")
  @Roles(Role.Admin)
  updateStatus(
    @Param("id") id: string,
    @Param("status", new ParseEnumPipe(ProgramStatus)) status: ProgramStatus
  ) {
    return this.programsService.updateStatus(id, status);
  }

  @Delete(":id")
  @Roles(Role.Admin)
  remove(@Param("id") id: string) {
    return this.programsService.remove(id);
  }
}
