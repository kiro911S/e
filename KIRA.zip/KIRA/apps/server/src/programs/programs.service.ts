import {
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { ProgramStatus } from "@ot/shared";
import { promises as fs } from "fs";
import * as path from "path";
import { PrismaService } from "../prisma/prisma.service";
import { CreateProgramDto } from "./dto/create-program.dto";
import { UpdateProgramDto } from "./dto/update-program.dto";

@Injectable()
export class ProgramsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll() {
    return this.prisma.briefingProgram.findMany({
      where: { isActive: true },
      include: { questions: { orderBy: { order: "asc" } }, briefingType: true },
      orderBy: { createdAt: "desc" }
    });
  }

  async findOne(id: string) {
    const program = await this.prisma.briefingProgram.findFirst({
      where: { id, isActive: true },
      include: {
        briefingType: true,
        questions: { orderBy: { order: "asc" } }
      }
    });
    if (!program) {
      throw new NotFoundException("Программа не найдена");
    }
    const document = await this.getProgramDocument(id);
    return {
      ...program,
      documentUrl: document?.url ?? null
    };
  }

  create(dto: CreateProgramDto) {
    return this.prisma.briefingProgram.create({
      data: {
        title: dto.title,
        description: dto.description,
        briefingTypeId: dto.briefingTypeId,
        status: dto.status,
        questions: {
          create: dto.questions
        }
      },
      include: { questions: true }
    });
  }

  async update(id: string, dto: UpdateProgramDto) {
    await this.ensureProgramExists(id);
    return this.prisma.briefingProgram.update({
      where: { id },
      data: {
        title: dto.title,
        description: dto.description,
        briefingTypeId: dto.briefingTypeId,
        status: dto.status,
        questions: dto.questions
          ? {
              deleteMany: {},
              create: dto.questions
            }
          : undefined
      },
      include: { questions: { orderBy: { order: "asc" } }, briefingType: true }
    });
  }

  async updateStatus(id: string, status: ProgramStatus) {
    await this.ensureProgramExists(id);
    return this.prisma.briefingProgram.update({
      where: { id },
      data: { status }
    });
  }

  async remove(id: string) {
    await this.ensureProgramExists(id);
    await this.prisma.briefingProgram.update({
      where: { id },
      data: { isActive: false, status: ProgramStatus.Archived }
    });
    return { success: true };
  }

  async listQuestions(id: string) {
    await this.ensureProgramExists(id);
    return this.prisma.programQuestion.findMany({
      where: { programId: id },
      orderBy: { order: "asc" }
    });
  }

  async saveProgramDocument(programId: string, file: Express.Multer.File) {
    await this.ensureProgramExists(programId);
    const directory = this.getUploadDirectory();
    await fs.mkdir(directory, { recursive: true });
    const targetPath = path.join(directory, `${programId}.pdf`);
    await fs.writeFile(targetPath, file.buffer);
    return this.getProgramDocument(programId);
  }

  async getProgramDocument(programId: string) {
    await this.ensureProgramExists(programId);
    const targetPath = path.join(this.getUploadDirectory(), `${programId}.pdf`);
    try {
      const stat = await fs.stat(targetPath);
      return {
        url: `/api/v1/programs/${programId}/document/download`,
        uploadedAt: stat.mtime.toISOString(),
        fileName: `${programId}.pdf`
      };
    } catch {
      return null;
    }
  }

  getProgramDocumentPath(programId: string) {
    return path.join(this.getUploadDirectory(), `${programId}.pdf`);
  }

  private async ensureProgramExists(id: string): Promise<void> {
    const program = await this.prisma.briefingProgram.findFirst({
      where: { id, isActive: true },
      select: { id: true }
    });
    if (!program) {
      throw new NotFoundException("Программа не найдена");
    }
  }

  private getUploadDirectory(): string {
    return path.resolve(process.cwd(), "uploads", "programs");
  }
}
