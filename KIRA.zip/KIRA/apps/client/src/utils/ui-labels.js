import { JournalStatus, ProgramStatus, Role, TestResultStatus, UserStatus } from "@ot/shared";
export const roleLabels = {
    [Role.Guest]: "Гость",
    [Role.Employee]: "Сотрудник",
    [Role.Inspector]: "Инспектор ОТ",
    [Role.Admin]: "Администратор"
};
export const userStatusLabels = {
    [UserStatus.Active]: "Активен",
    [UserStatus.Inactive]: "Неактивен"
};
export const programStatusLabels = {
    [ProgramStatus.Draft]: "Черновик",
    [ProgramStatus.Published]: "Опубликована",
    [ProgramStatus.Archived]: "В архиве"
};
export const journalStatusLabels = {
    [JournalStatus.Planned]: "Запланирован",
    [JournalStatus.InProgress]: "В процессе",
    [JournalStatus.Completed]: "Проведён",
    [JournalStatus.Cancelled]: "Отменён"
};
export const testResultStatusLabels = {
    [TestResultStatus.Passed]: "Пройден",
    [TestResultStatus.Failed]: "Не пройден"
};
export const roleOptions = Object.values(Role).map((value) => ({
    value,
    label: roleLabels[value]
}));
export const userStatusOptions = Object.values(UserStatus).map((value) => ({
    value,
    label: userStatusLabels[value]
}));
export const programStatusOptions = Object.values(ProgramStatus).map((value) => ({
    value,
    label: programStatusLabels[value]
}));
export const journalStatusOptions = Object.values(JournalStatus).map((value) => ({
    value,
    label: journalStatusLabels[value]
}));
export const testResultStatusOptions = Object.values(TestResultStatus).map((value) => ({
    value,
    label: testResultStatusLabels[value]
}));
export function getRoleLabel(value) {
    return (value && roleLabels[value]) || value || "Неизвестно";
}
export function getUserStatusLabel(value) {
    return (value && userStatusLabels[value]) || value || "Неизвестно";
}
export function getProgramStatusLabel(value) {
    return (value && programStatusLabels[value]) || value || "Неизвестно";
}
export function getJournalStatusLabel(value) {
    return (value && journalStatusLabels[value]) || value || "Неизвестно";
}
export function getTestResultStatusLabel(value) {
    return (value && testResultStatusLabels[value]) || value || "Неизвестно";
}
