export function formatDateRu(input: string | Date): string {
  const date = input instanceof Date ? input : new Date(input);
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
}

export function toIsoDate(input: Date): string {
  return input.toISOString().slice(0, 10);
}

export function getCurrentYearRange(): { from: string; to: string } {
  const currentYear = new Date().getFullYear();
  return {
    from: `${currentYear}-01-01`,
    to: `${currentYear}-12-31`
  };
}
