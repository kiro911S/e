import { JournalStatus, ProgramStatus, Role, TestResultStatus, UserStatus } from "@ot/shared";

export const roleLabels: Record<Role, string> = {
  [Role.Guest]: "Гость",
  [Role.Employee]: "Сотрудник",
  [Role.Inspector]: "Инспектор ОТ",
  [Role.Admin]: "Администратор"
};

export const userStatusLabels: Record<UserStatus, string> = {
  [UserStatus.Active]: "Активен",
  [UserStatus.Inactive]: "Неактивен"
};

export const programStatusLabels: Record<ProgramStatus, string> = {
  [ProgramStatus.Draft]: "Черновик",
  [ProgramStatus.Published]: "Опубликована",
  [ProgramStatus.Archived]: "В архиве"
};

export const journalStatusLabels: Record<JournalStatus, string> = {
  [JournalStatus.Planned]: "Запланирован",
  [JournalStatus.InProgress]: "В процессе",
  [JournalStatus.Completed]: "Проведён",
  [JournalStatus.Cancelled]: "Отменён"
};

export const testResultStatusLabels: Record<TestResultStatus, string> = {
  [TestResultStatus.Passed]: "Пройден",
  [TestResultStatus.Failed]: "Не пройден"
};

export const roleOptions = Object.values(Role).map((value) => ({
  value,
  label: roleLabels[value]
}));

export const userStatusOptions = Object.values(UserStatus).map((value) => ({
  value,
  label: userStatusLabels[value]
}));

export const programStatusOptions = Object.values(ProgramStatus).map((value) => ({
  value,
  label: programStatusLabels[value]
}));

export const journalStatusOptions = Object.values(JournalStatus).map((value) => ({
  value,
  label: journalStatusLabels[value]
}));

export const testResultStatusOptions = Object.values(TestResultStatus).map((value) => ({
  value,
  label: testResultStatusLabels[value]
}));

export function getRoleLabel(value: string | undefined): string {
  return (value && roleLabels[value as Role]) || value || "Неизвестно";
}

export function getUserStatusLabel(value: string | undefined): string {
  return (value && userStatusLabels[value as UserStatus]) || value || "Неизвестно";
}

export function getProgramStatusLabel(value: string | undefined): string {
  return (value && programStatusLabels[value as ProgramStatus]) || value || "Неизвестно";
}

export function getJournalStatusLabel(value: string | undefined): string {
  return (value && journalStatusLabels[value as JournalStatus]) || value || "Неизвестно";
}

export function getTestResultStatusLabel(value: string | undefined): string {
  return (value && testResultStatusLabels[value as TestResultStatus]) || value || "Неизвестно";
}
