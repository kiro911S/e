import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import type { CreateProgramPayload } from "../api/programs-api";
import { programsApi } from "../api/programs-api";

export function usePrograms() {
  return useQuery({
    queryKey: appKeys.programs.all,
    queryFn: programsApi.getAll
  });
}

export function useCreateProgram() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateProgramPayload) => programsApi.create(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.programs.all });
    }
  });
}
