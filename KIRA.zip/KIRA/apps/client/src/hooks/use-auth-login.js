import { useMutation } from "@tanstack/react-query";
import { authApi } from "../api/auth-api";
import { useAuthStore } from "../store/auth-store";
export function useAuthLogin() {
    const setAuth = useAuthStore((state) => state.setAuth);
    return useMutation({
        mutationFn: (payload) => authApi.login(payload),
        onSuccess: (data) => {
            setAuth({ token: data.accessToken, user: data.user });
        }
    });
}
