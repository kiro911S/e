import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import type { CreateBriefingTypePayload, CreateDepartmentPayload, CreatePositionPayload } from "../api/directories-api";
import { directoriesApi } from "../api/directories-api";

export function useDepartments() {
  return useQuery({
    queryKey: appKeys.directories.departments,
    queryFn: directoriesApi.getDepartments
  });
}

export function usePositions() {
  return useQuery({
    queryKey: appKeys.directories.positions,
    queryFn: directoriesApi.getPositions
  });
}

export function useBriefingTypes() {
  return useQuery({
    queryKey: appKeys.directories.briefingTypes,
    queryFn: directoriesApi.getBriefingTypes
  });
}

export function useCreateDepartment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateDepartmentPayload) => directoriesApi.createDepartment(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.directories.departments });
    }
  });
}

export function useCreatePosition() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreatePositionPayload) => directoriesApi.createPosition(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.directories.positions });
    }
  });
}

export function useCreateBriefingType() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateBriefingTypePayload) => directoriesApi.createBriefingType(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.directories.briefingTypes });
    }
  });
}
