import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import { programsApi } from "../api/programs-api";
export function usePrograms() {
    return useQuery({
        queryKey: appKeys.programs.all,
        queryFn: programsApi.getAll
    });
}
export function useCreateProgram() {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: (payload) => programsApi.create(payload),
        onSuccess: async () => {
            await queryClient.invalidateQueries({ queryKey: appKeys.programs.all });
        }
    });
}
