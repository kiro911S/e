import { useMutation } from "@tanstack/react-query";
import { LoginDto } from "@ot/shared";
import { authApi } from "../api/auth-api";
import { useAuthStore } from "../store/auth-store";

export function useAuthLogin() {
  const setAuth = useAuthStore((state) => state.setAuth);
  return useMutation({
    mutationFn: (payload: LoginDto) => authApi.login(payload),
    onSuccess: (data) => {
      setAuth({ token: data.accessToken, user: data.user });
    }
  });
}
