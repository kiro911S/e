import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import type { CreateUserPayload } from "../api/users-api";
import { usersApi } from "../api/users-api";

export function useUsers() {
  return useQuery({
    queryKey: appKeys.users.all,
    queryFn: usersApi.getAll
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateUserPayload) => usersApi.create(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.users.all });
    }
  });
}
