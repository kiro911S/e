import { useQuery } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import { reportsApi } from "../api/reports-api";
export function useCompletionReport(from, to) {
    return useQuery({
        queryKey: appKeys.reports.completion(from, to),
        queryFn: () => reportsApi.getCompletion(from, to)
    });
}
export function useReportsSummary() {
    return useQuery({
        queryKey: ["reports", "summary"],
        queryFn: reportsApi.getSummary
    });
}
export function useUpcomingBriefings(days = 14) {
    return useQuery({
        queryKey: ["reports", "upcoming", days],
        queryFn: () => reportsApi.getUpcoming(days)
    });
}
export function useOverdueBriefings() {
    return useQuery({
        queryKey: ["reports", "overdue"],
        queryFn: reportsApi.getOverdue
    });
}
export function useEmployeeHistory(employeeId) {
    return useQuery({
        queryKey: ["reports", "employee-history", employeeId],
        queryFn: () => reportsApi.getEmployeeHistory(employeeId ?? ""),
        enabled: Boolean(employeeId)
    });
}
export function downloadCompletionCsv(fileName, content) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(content);
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(link.href);
}
