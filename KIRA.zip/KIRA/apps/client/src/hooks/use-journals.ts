import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import type { CreateJournalPayload } from "../api/journals-api";
import { journalsApi } from "../api/journals-api";

export function useJournals() {
  return useQuery({
    queryKey: appKeys.journals.all,
    queryFn: journalsApi.getAll
  });
}

export function useCreateJournal() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateJournalPayload) => journalsApi.create(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.journals.all });
    }
  });
}
