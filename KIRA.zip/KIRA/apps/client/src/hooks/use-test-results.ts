import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { appKeys } from "../api/query-keys";
import type { SubmitTestPayload } from "../api/tests-api";
import { testsApi } from "../api/tests-api";

export function useTestResults() {
  return useQuery({
    queryKey: appKeys.tests.results,
    queryFn: testsApi.getResults
  });
}

export function useSubmitTest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: SubmitTestPayload) => testsApi.submit(payload),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: appKeys.tests.results });
    }
  });
}
