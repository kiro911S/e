import type { ColumnsType } from "antd/es/table";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import { Role, UserStatus } from "@ot/shared";
import { useMemo, useState } from "react";
import { useDepartments, usePositions } from "../hooks/use-directories";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import type { CreateUserPayload, UserItem } from "../api/users-api";
import { useCreateUser, useUsers } from "../hooks/use-users";
import { getRoleLabel, getUserStatusLabel, roleOptions, userStatusOptions } from "../utils/ui-labels";

export function UsersPage() {
  const [form] = Form.useForm<CreateUserPayload>();
  const [isModalOpen, setModalOpen] = useState(false);
  const usersQuery = useUsers();
  const createUserMutation = useCreateUser();
  const departmentsQuery = useDepartments();
  const positionsQuery = usePositions();
  const canManageUsers = useCan("users:write");
  const [search, setSearch] = useState("");

  const departmentOptions = useMemo(
    () =>
      (departmentsQuery.data ?? []).map((department) => ({
        value: department.id,
        label: department.name
      })),
    [departmentsQuery.data]
  );

  const positionOptions = useMemo(
    () =>
      (positionsQuery.data ?? []).map((position) => ({
        value: position.id,
        label: position.name
      })),
    [positionsQuery.data]
  );

  const columns = useMemo<ColumnsType<UserItem>>(
    () => [
      { title: "ФИО", dataIndex: "fullName" },
      { title: "Эл. почта", dataIndex: "email" },
      {
        title: "Роль",
        dataIndex: "role",
        render: (value: string) => <Tag color={value === Role.Admin ? "red" : "blue"}>{getRoleLabel(value)}</Tag>
      },
      {
        title: "Статус",
        dataIndex: "status",
        render: (value: string) => <Tag color={value === UserStatus.Active ? "green" : "default"}>{getUserStatusLabel(value)}</Tag>
      }
    ],
    []
  );

  const filteredUsers = useMemo(() => {
    const source = usersQuery.data ?? [];
    const normalized = search.trim().toLowerCase();
    if (!normalized) {
      return source;
    }
    return source.filter(
      (item) =>
        item.fullName.toLowerCase().includes(normalized) ||
        item.email.toLowerCase().includes(normalized)
    );
  }, [search, usersQuery.data]);

  const openCreateModal = () => {
    form.setFieldsValue({
      role: Role.Employee,
      status: UserStatus.Active
    });
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    const values = await form.validateFields();
    await createUserMutation.mutateAsync(values);
    setModalOpen(false);
    form.resetFields();
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader
        title="Пользователи"
        description="Управление сотрудниками и ролями доступа"
        actionText={canManageUsers ? "Добавить" : undefined}
        onActionClick={canManageUsers ? openCreateModal : undefined}
      />
      <Input.Search
        placeholder="Поиск по ФИО или email"
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        allowClear
      />
      <PageState isLoading={usersQuery.isLoading} isError={usersQuery.isError} errorTitle="Не удалось загрузить пользователей">
        {filteredUsers.length > 0 ? (
          <EntityTable columns={columns} data={filteredUsers} />
        ) : (
          <EmptyState description="Пользователи пока не добавлены" />
        )}
      </PageState>
      <EntityFormModal
        title="Новый пользователь"
        open={isModalOpen}
        onCancel={() => setModalOpen(false)}
        onSubmit={handleSubmit}
        confirmLoading={createUserMutation.isPending}
      >
        <Form form={form} layout="vertical" preserve={false}>
          <Form.Item label="ФИО" name="fullName" rules={[{ required: true, message: "Введите ФИО" }]}>
            <Input placeholder="Иванов Иван Иванович" />
          </Form.Item>
          <Form.Item label="Эл. почта" name="email" rules={[{ required: true, message: "Введите email" }]}>
            <Input placeholder="employee@example.com" />
          </Form.Item>
          <Form.Item label="Роль" name="role" rules={[{ required: true, message: "Выберите роль" }]}>
            <Select
              options={roleOptions}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите роль"
              notFoundContent="Роли не найдены"
            />
          </Form.Item>
          <Form.Item label="Подразделение" name="departmentId" rules={[{ required: true, message: "Выберите подразделение" }]}>
            <Select
              options={departmentOptions}
              loading={departmentsQuery.isLoading}
              disabled={departmentsQuery.isLoading || departmentsQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите подразделение"
              notFoundContent="Подразделения не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Должность" name="positionId" rules={[{ required: true, message: "Выберите должность" }]}>
            <Select
              options={positionOptions}
              loading={positionsQuery.isLoading}
              disabled={positionsQuery.isLoading || positionsQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите должность"
              notFoundContent="Должности не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Дата приёма" name="hireDate" rules={[{ required: true, message: "Укажите дату в формате YYYY-MM-DD" }]}>
            <Input placeholder="2026-05-16" />
          </Form.Item>
          <Form.Item label="Статус" name="status" rules={[{ required: true, message: "Выберите статус" }]}>
            <Select
              options={userStatusOptions}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите статус"
              notFoundContent="Статусы не найдены"
            />
          </Form.Item>
          {createUserMutation.isError ? <Button danger block>Не удалось создать пользователя</Button> : null}
        </Form>
      </EntityFormModal>
    </Space>
  );
}
