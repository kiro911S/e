import { Button, Form, Input, Select, Space, Tag } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useMemo, useState } from "react";
import type { SubmitTestPayload, TestResultItem } from "../api/tests-api";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useJournals } from "../hooks/use-journals";
import { usePrograms } from "../hooks/use-programs";
import { useSubmitTest, useTestResults } from "../hooks/use-test-results";
import { getJournalStatusLabel, getTestResultStatusLabel } from "../utils/ui-labels";
import { useAuthStore } from "../store/auth-store";

export function TestsPage() {
  const [form] = Form.useForm<SubmitTestPayload>();
  const [isModalOpen, setModalOpen] = useState(false);
  const results = useTestResults();
  const submitTest = useSubmitTest();
  const journalsQuery = useJournals();
  const programsQuery = usePrograms();
  const canSubmitTest = useCan("tests:submit");
  const currentUser = useAuthStore((state) => state.user);

  const journalOptions = useMemo(
    () =>
      (journalsQuery.data ?? []).map((journal) => ({
        value: journal.id,
        label: `${journal.id.slice(0, 8)}... (${getJournalStatusLabel(journal.status)})`
      })),
    [journalsQuery.data]
  );

  const columns = useMemo<ColumnsType<TestResultItem>>(
    () => [
      {
        title: "Сотрудник",
        dataIndex: "employeeId",
        render: (value?: string) =>
          value && value === currentUser?.id
            ? currentUser.fullName
            : (value ?? "—")
      },
      {
        title: "Балл",
        dataIndex: "score",
        render: (value: number) => `${value}%`
      },
      {
        title: "Статус",
        dataIndex: "status",
        render: (value: string) => <Tag color={value === "Passed" ? "green" : "red"}>{getTestResultStatusLabel(value)}</Tag>
      }
    ],
    [currentUser]
  );

  const submit = async () => {
    const values = await form.validateFields();
    const selectedJournal = (journalsQuery.data ?? []).find((journal) => journal.id === values.journalId);
    const selectedProgram = (programsQuery.data ?? []).find((program) => program.id === selectedJournal?.programId);
    const questionId = selectedProgram?.questions?.[0]?.id ?? "00000000-0000-0000-0000-000000000001";
    await submitTest.mutateAsync({
      journalId: values.journalId,
      answers: [
        {
          questionId,
          answer: values.answers?.[0]?.answer ?? "Да"
        }
      ]
    });
    setModalOpen(false);
    form.resetFields();
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader
        title="Результаты тестирования"
        description="Онлайн-тест после инструктажей"
        actionText={canSubmitTest ? "Пройти тест" : undefined}
        onActionClick={canSubmitTest ? () => setModalOpen(true) : undefined}
      />
      <PageState isLoading={results.isLoading} isError={results.isError} errorTitle="Не удалось загрузить результаты тестирования">
        {results.data && results.data.length > 0 ? (
          <EntityTable columns={columns} data={results.data} />
        ) : (
          <EmptyState description="Результатов тестирования пока нет" />
        )}
      </PageState>
      <EntityFormModal
        title="Прохождение теста"
        open={isModalOpen}
        onCancel={() => setModalOpen(false)}
        onSubmit={submit}
        confirmLoading={submitTest.isPending}
      >
        <Form layout="vertical" form={form} preserve={false}>
          <Form.Item label="Журнал инструктажа" name="journalId" rules={[{ required: true, message: "Выберите журнал" }]}>
            <Select
              options={journalOptions}
              loading={journalsQuery.isLoading}
              disabled={journalsQuery.isLoading || journalsQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите журнал"
              notFoundContent="Журналы не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Сотрудник">
            <Input value={currentUser?.fullName ?? "—"} disabled />
          </Form.Item>
          <Form.Item label="Ваш ответ" name={["answers", 0, "answer"]} rules={[{ required: true, message: "Введите ответ" }]}>
            <Input placeholder="Введите ответ на вопрос" />
          </Form.Item>
          {submitTest.isError ? <Button danger block>Не удалось отправить результат</Button> : null}
        </Form>
      </EntityFormModal>
    </Space>
  );
}
