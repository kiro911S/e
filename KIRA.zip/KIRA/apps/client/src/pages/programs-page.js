import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useBriefingTypes } from "../hooks/use-directories";
import { useCreateProgram, usePrograms } from "../hooks/use-programs";
import { getProgramStatusLabel, programStatusOptions } from "../utils/ui-labels";
export function ProgramsPage() {
    const [form] = Form.useForm();
    const [isModalOpen, setModalOpen] = useState(false);
    const programs = usePrograms();
    const createProgram = useCreateProgram();
    const briefingTypesQuery = useBriefingTypes();
    const canManagePrograms = useCan("programs:write");
    const [search, setSearch] = useState("");
    const briefingTypeOptions = useMemo(() => (briefingTypesQuery.data ?? []).map((item) => ({
        value: item.id,
        label: item.name
    })), [briefingTypesQuery.data]);
    const columns = useMemo(() => [
        { title: "Название", dataIndex: "title" },
        {
            title: "Статус",
            dataIndex: "status",
            render: (value) => _jsx(Tag, { color: value === "Published" ? "green" : "default", children: getProgramStatusLabel(value) })
        },
        {
            title: "Вопросы",
            render: (_, item) => item.questions?.length ?? 0
        }
    ], []);
    const filteredPrograms = useMemo(() => {
        const source = programs.data ?? [];
        const normalized = search.trim().toLowerCase();
        if (!normalized) {
            return source;
        }
        return source.filter((item) => item.title.toLowerCase().includes(normalized));
    }, [programs.data, search]);
    const submit = async () => {
        const values = await form.validateFields();
        const payload = {
            ...values,
            questions: [
                {
                    text: values.questions?.[0]?.text ?? "Контрольный вопрос",
                    order: 1,
                    isRequired: true
                }
            ]
        };
        await createProgram.mutateAsync(payload);
        setModalOpen(false);
        form.resetFields();
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", description: "\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C \u0438 \u0442\u0435\u0441\u0442\u043E\u0432\u044B\u0445 \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u0432", actionText: canManagePrograms ? "Создать программу" : undefined, onActionClick: canManagePrograms ? () => setModalOpen(true) : undefined }), _jsx(Input.Search, { placeholder: "\u041F\u043E\u0438\u0441\u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", value: search, onChange: (event) => setSearch(event.target.value), allowClear: true }), _jsx(PageState, { isLoading: programs.isLoading, isError: programs.isError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", children: filteredPrograms.length > 0 ? (_jsx(EntityTable, { columns: columns, data: filteredPrograms })) : (_jsx(EmptyState, { description: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u043F\u043E\u043A\u0430 \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B" })) }), _jsx(EntityFormModal, { title: "\u041D\u043E\u0432\u0430\u044F \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", open: isModalOpen, onCancel: () => setModalOpen(false), onSubmit: submit, confirmLoading: createProgram.isPending, children: _jsxs(Form, { layout: "vertical", form: form, preserve: false, children: [_jsx(Form.Item, { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", name: "title", rules: [{ required: true, message: "Введите название" }], children: _jsx(Input, {}) }), _jsx(Form.Item, { label: "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435", name: "description", children: _jsx(Input.TextArea, { rows: 3 }) }), _jsx(Form.Item, { label: "\u0412\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", name: "briefingTypeId", rules: [{ required: true, message: "Выберите вид инструктажа" }], children: _jsx(Select, { options: briefingTypeOptions, loading: briefingTypesQuery.isLoading, disabled: briefingTypesQuery.isLoading || briefingTypesQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0438\u0434 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", notFoundContent: "\u0412\u0438\u0434\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0421\u0442\u0430\u0442\u0443\u0441", name: "status", initialValue: "Draft", rules: [{ required: true, message: "Выберите статус" }], children: _jsx(Select, { options: programStatusOptions, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u0430\u0442\u0443\u0441", notFoundContent: "\u0421\u0442\u0430\u0442\u0443\u0441\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B" }) }), _jsx(Form.Item, { label: "\u041F\u0435\u0440\u0432\u044B\u0439 \u0432\u043E\u043F\u0440\u043E\u0441", name: ["questions", 0, "text"], rules: [{ required: true, message: "Введите вопрос" }], children: _jsx(Input, {}) }), createProgram.isError ? _jsx(Button, { danger: true, block: true, children: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443" }) : null] }) })] }));
}
