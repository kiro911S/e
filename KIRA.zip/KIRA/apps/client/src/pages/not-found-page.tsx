import { Button, Result } from "antd";
import { useNavigate } from "react-router-dom";

export function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <Result
      status="404"
      title="Страница не найдена"
      subTitle="Проверьте адрес или вернитесь в меню."
      extra={
        <Button type="primary" onClick={() => navigate("/dashboard")}>
          На главную
        </Button>
      }
    />
  );
}
