import { Avatar, Card, Col, List, Row, Space, Tag, Typography } from "antd";
import { UserOutlined } from "@ant-design/icons";
import { PageHeader } from "../components/common/page-header";
import { useEmployeeHistory } from "../hooks/use-reports";
import { formatDateRu } from "../utils/date";
import { useAuthStore } from "../store/auth-store";
import { getRoleLabel } from "../utils/ui-labels";

export function ProfilePage() {
  const user = useAuthStore((state) => state.user);
  const historyQuery = useEmployeeHistory(user?.id);
  const history = historyQuery.data?.records ?? [];

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader title="Личный кабинет" description="История и статус инструктажей сотрудника" />
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={8}>
          <Card>
            <Space direction="vertical" size={8}>
              <Avatar size={64} icon={<UserOutlined />} />
              <Typography.Title level={4} style={{ margin: 0 }}>
                {user?.fullName ?? "Неизвестно"}
              </Typography.Title>
              <Typography.Text>{user?.email ?? "Неизвестно"}</Typography.Text>
              <Tag color="blue">{getRoleLabel(user?.role)}</Tag>
            </Space>
          </Card>
        </Col>
        <Col xs={24} lg={16}>
          <Card title="История инструктажей">
            <List
              dataSource={history}
              renderItem={(item) => (
                <List.Item>
                  <List.Item.Meta
                    title={item.journal.program.title}
                    description={`Дата: ${formatDateRu(item.journal.briefingDate)}`}
                  />
                  <Tag color={item.signedAt ? "green" : "default"}>
                    {item.signedAt ? "Подписано" : "Ожидает подпись"}
                  </Tag>
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>
    </Space>
  );
}
