import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Form, Input, InputNumber, Space, Tabs } from "antd";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useBriefingTypes, useCreateBriefingType, useCreateDepartment, useCreatePosition, useDepartments, usePositions } from "../hooks/use-directories";
export function DirectoriesPage() {
    const [form] = Form.useForm();
    const [activeTab, setActiveTab] = useState("departments");
    const [isModalOpen, setModalOpen] = useState(false);
    const departments = useDepartments();
    const positions = usePositions();
    const briefingTypes = useBriefingTypes();
    const createDepartment = useCreateDepartment();
    const createPosition = useCreatePosition();
    const createBriefingType = useCreateBriefingType();
    const canManageDirectories = useCan("directories:write");
    const columns = useMemo(() => [
        { title: "Название", dataIndex: "name" },
        { title: "Код / периодичность", dataIndex: "extra" }
    ], []);
    const dataByTab = {
        departments: (departments.data ?? []).map((item) => ({ ...item, extra: item.code ?? "-" })),
        positions: (positions.data ?? []).map((item) => ({ ...item, extra: "-" })),
        briefingTypes: (briefingTypes.data ?? []).map((item) => ({ ...item, extra: item.periodicityMonths ? `${item.periodicityMonths} мес.` : "-" }))
    };
    const loadingByTab = {
        departments: departments.isLoading,
        positions: positions.isLoading,
        briefingTypes: briefingTypes.isLoading
    };
    const errorByTab = {
        departments: departments.isError,
        positions: positions.isError,
        briefingTypes: briefingTypes.isError
    };
    const currentData = dataByTab[activeTab] ?? [];
    const isCurrentLoading = loadingByTab[activeTab] ?? false;
    const isCurrentError = errorByTab[activeTab] ?? false;
    const submitForm = async () => {
        const values = await form.validateFields();
        if (activeTab === "departments") {
            await createDepartment.mutateAsync(values);
        }
        if (activeTab === "positions") {
            await createPosition.mutateAsync(values);
        }
        if (activeTab === "briefingTypes") {
            await createBriefingType.mutateAsync(values);
        }
        setModalOpen(false);
        form.resetFields();
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438", description: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F, \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438 \u0438 \u0432\u0438\u0434\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", actionText: canManageDirectories ? "Добавить запись" : undefined, onActionClick: canManageDirectories ? () => setModalOpen(true) : undefined }), _jsx(Tabs, { activeKey: activeTab, onChange: (key) => setActiveTab(key), items: [
                    { key: "departments", label: "Подразделения" },
                    { key: "positions", label: "Должности" },
                    { key: "briefingTypes", label: "Виды инструктажей" }
                ] }), _jsx(PageState, { isLoading: isCurrentLoading, isError: isCurrentError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A", children: currentData.length > 0 ? (_jsx(EntityTable, { columns: columns, data: currentData })) : (_jsx(EmptyState, { description: "\u0412 \u044D\u0442\u043E\u043C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0435 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u0435\u0439" })) }), _jsx(EntityFormModal, { title: "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430", open: isModalOpen, onCancel: () => setModalOpen(false), onSubmit: submitForm, confirmLoading: createDepartment.isPending || createPosition.isPending || createBriefingType.isPending, children: _jsxs(Form, { layout: "vertical", form: form, preserve: false, children: [_jsx(Form.Item, { label: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435", name: "name", rules: [{ required: true, message: "Введите название" }], children: _jsx(Input, {}) }), activeTab === "departments" ? (_jsx(Form.Item, { label: "\u041A\u043E\u0434", name: "code", rules: [{ required: true, message: "Введите код" }], children: _jsx(Input, {}) })) : null, activeTab === "briefingTypes" ? (_jsx(Form.Item, { label: "\u041F\u0435\u0440\u0438\u043E\u0434\u0438\u0447\u043D\u043E\u0441\u0442\u044C (\u043C\u0435\u0441\u044F\u0446\u044B)", name: "periodicityMonths", rules: [{ required: true, message: "Укажите периодичность" }], children: _jsx(InputNumber, { min: 1, max: 36, style: { width: "100%" } }) })) : null, createDepartment.isError || createPosition.isError || createBriefingType.isError ? (_jsx(Button, { danger: true, block: true, children: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C" })) : null] }) })] }));
}
