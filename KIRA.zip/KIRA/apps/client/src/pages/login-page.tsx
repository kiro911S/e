import { LockOutlined, MailOutlined } from "@ant-design/icons";
import { Role } from "@ot/shared";
import { Alert, Button, Card, Form, Input, Typography } from "antd";
import { useNavigate } from "react-router-dom";
import { useAuthLogin } from "../hooks/use-auth-login";

export function LoginPage() {
  const navigate = useNavigate();
  const loginMutation = useAuthLogin();

  const onSubmit = async (values: { email: string; password: string }) => {
    const response = await loginMutation.mutateAsync(values);
    const targetPath = response.user.role === Role.Admin ? "/admin/users" : "/dashboard";
    navigate(targetPath, { replace: true });
  };

  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16 }}>
      <Card style={{ width: 420 }}>
        <Typography.Title level={3}>Вход в систему</Typography.Title>
        <Typography.Paragraph type="secondary">
          Учёт и проведение инструктажей по охране труда
        </Typography.Paragraph>
        <Form
          layout="vertical"
          initialValues={{ email: "admin@example.com", password: "ChangeMe123!" }}
          onFinish={onSubmit}
          autoComplete="off"
        >
          <Form.Item
            label="Эл. почта"
            name="email"
            rules={[
              { required: true, message: "Введите email" },
              { type: "email", message: "Некорректный email" }
            ]}
          >
            <Input prefix={<MailOutlined />} placeholder="admin@example.com" />
          </Form.Item>
          <Form.Item
            label="Пароль"
            name="password"
            rules={[{ required: true, message: "Введите пароль" }]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="Введите пароль" />
          </Form.Item>
          <Button type="primary" htmlType="submit" block loading={loginMutation.isPending}>
            Войти
          </Button>
        </Form>
        {loginMutation.isError ? (
          <Alert
            style={{ marginTop: 16 }}
            type="error"
            showIcon
            message="Не удалось войти"
            description="Проверьте email и пароль, затем повторите попытку."
          />
        ) : null}
      </Card>
    </main>
  );
}
