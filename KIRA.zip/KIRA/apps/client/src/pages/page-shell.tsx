import { LogoutOutlined, MoonOutlined, SunOutlined } from "@ant-design/icons";
import { Breadcrumb, Button, Layout, Menu, Space, Switch, theme, Typography } from "antd";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { authApi } from "../api/auth-api";
import { buildMenuItems, getRouteTitle } from "../app/navigation/menu-builder";
import { useThemeMode } from "../app/providers/antd-provider";
import { useAuthStore } from "../store/auth-store";

const { Header, Content, Sider } = Layout;

export function PageShell() {
  const { logout, user } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const { isDarkMode, toggleThemeMode } = useThemeMode();
  const { token } = theme.useToken();

  const menuItems = buildMenuItems(user?.role);
  const currentPath = location.pathname;
  const currentTitle = getRouteTitle(currentPath);

  const onLogout = () => {
    void authApi.logout().catch(() => undefined);
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Sider breakpoint="lg" collapsedWidth={64}>
        <div style={{ color: "#fff", fontSize: 18, fontWeight: 600, padding: "16px 20px" }}>KIRA OT</div>
        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={[currentPath]}
          items={menuItems}
          onClick={({ key }) => {
            navigate(String(key));
          }}
        />
      </Sider>
      <Layout>
        <Header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingInline: 20 }}>
          <Typography.Title level={4} style={{ margin: 0 }}>
            {currentTitle}
          </Typography.Title>
          <Space>
            <Typography.Text>{user?.fullName ?? "Пользователь"}</Typography.Text>
            <Switch
              checked={isDarkMode}
              checkedChildren={<MoonOutlined />}
              unCheckedChildren={<SunOutlined />}
              onChange={toggleThemeMode}
            />
            <Button icon={<LogoutOutlined />} onClick={onLogout}>
              Выйти
            </Button>
          </Space>
        </Header>
        <Content style={{ margin: 20 }}>
          <Breadcrumb
            style={{ marginBottom: 16 }}
            items={[
              { title: "Главная" },
              { title: currentTitle }
            ]}
          />
          <div
            style={{
              padding: 20,
              minHeight: 360,
              background: token.colorBgContainer,
              borderRadius: token.borderRadiusLG
            }}
          >
            <Outlet />
          </div>
        </Content>
      </Layout>
    </Layout>
  );
}
