import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { LockOutlined, MailOutlined } from "@ant-design/icons";
import { Role } from "@ot/shared";
import { Alert, Button, Card, Form, Input, Typography } from "antd";
import { useNavigate } from "react-router-dom";
import { useAuthLogin } from "../hooks/use-auth-login";
export function LoginPage() {
    const navigate = useNavigate();
    const loginMutation = useAuthLogin();
    const onSubmit = async (values) => {
        const response = await loginMutation.mutateAsync(values);
        const targetPath = response.user.role === Role.Admin ? "/admin/users" : "/dashboard";
        navigate(targetPath, { replace: true });
    };
    return (_jsx("main", { style: { minHeight: "100vh", display: "grid", placeItems: "center", padding: 16 }, children: _jsxs(Card, { style: { width: 420 }, children: [_jsx(Typography.Title, { level: 3, children: "\u0412\u0445\u043E\u0434 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0443" }), _jsx(Typography.Paragraph, { type: "secondary", children: "\u0423\u0447\u0451\u0442 \u0438 \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439 \u043F\u043E \u043E\u0445\u0440\u0430\u043D\u0435 \u0442\u0440\u0443\u0434\u0430" }), _jsxs(Form, { layout: "vertical", initialValues: { email: "admin@example.com", password: "ChangeMe123!" }, onFinish: onSubmit, autoComplete: "off", children: [_jsx(Form.Item, { label: "\u042D\u043B. \u043F\u043E\u0447\u0442\u0430", name: "email", rules: [
                                { required: true, message: "Введите email" },
                                { type: "email", message: "Некорректный email" }
                            ], children: _jsx(Input, { prefix: _jsx(MailOutlined, {}), placeholder: "admin@example.com" }) }), _jsx(Form.Item, { label: "\u041F\u0430\u0440\u043E\u043B\u044C", name: "password", rules: [{ required: true, message: "Введите пароль" }], children: _jsx(Input.Password, { prefix: _jsx(LockOutlined, {}), placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0430\u0440\u043E\u043B\u044C" }) }), _jsx(Button, { type: "primary", htmlType: "submit", block: true, loading: loginMutation.isPending, children: "\u0412\u043E\u0439\u0442\u0438" })] }), loginMutation.isError ? (_jsx(Alert, { style: { marginTop: 16 }, type: "error", showIcon: true, message: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u043E\u0439\u0442\u0438", description: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 email \u0438 \u043F\u0430\u0440\u043E\u043B\u044C, \u0437\u0430\u0442\u0435\u043C \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u043E\u043F\u044B\u0442\u043A\u0443." })) : null] }) }));
}
