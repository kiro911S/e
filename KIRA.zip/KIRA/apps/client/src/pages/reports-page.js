import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { DownloadOutlined } from "@ant-design/icons";
import { Button, Card, DatePicker, Flex, Space, Statistic, Table, Tabs } from "antd";
import dayjs from "dayjs";
import { useMemo, useState } from "react";
import { reportsApi } from "../api/reports-api";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { downloadCompletionCsv, useCompletionReport, useOverdueBriefings } from "../hooks/use-reports";
import { formatDateRu, getCurrentYearRange, toIsoDate } from "../utils/date";
export function ReportsPage() {
    const defaultRange = getCurrentYearRange();
    const [from, setFrom] = useState(defaultRange.from);
    const [to, setTo] = useState(defaultRange.to);
    const report = useCompletionReport(from, to);
    const overdue = useOverdueBriefings();
    const totals = useMemo(() => (report.data ?? []).reduce((acc, item) => {
        acc.total += item.totalEmployees;
        acc.completed += item.completed;
        acc.failed += item.failed;
        return acc;
    }, { total: 0, completed: 0, failed: 0 }), [report.data]);
    const exportCsv = () => {
        if (!report.data?.length) {
            return;
        }
        const file = reportsApi.exportCompletionCsv(report.data);
        downloadCompletionCsv(`ot-report-${from}-${to}.csv`, file);
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u041E\u0442\u0447\u0451\u0442\u044B", description: "\u0421\u0432\u043E\u0434\u043A\u0430 \u0438 \u043F\u0440\u043E\u0441\u0440\u043E\u0447\u0435\u043D\u043D\u044B\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0438" }), _jsxs(Flex, { gap: 12, wrap: true, align: "center", children: [_jsx(DatePicker, { value: dayjs(from), format: "DD.MM.YYYY", onChange: (value) => {
                            if (value)
                                setFrom(toIsoDate(value.toDate()));
                        } }), _jsx(DatePicker, { value: dayjs(to), format: "DD.MM.YYYY", onChange: (value) => {
                            if (value)
                                setTo(toIsoDate(value.toDate()));
                        } }), _jsx(Button, { icon: _jsx(DownloadOutlined, {}), onClick: exportCsv, children: "\u042D\u043A\u0441\u043F\u043E\u0440\u0442 CSV" })] }), _jsx(PageState, { isLoading: report.isLoading, isError: report.isError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043E\u0442\u0447\u0451\u0442", children: _jsx(Tabs, { items: [
                        {
                            key: "summary",
                            label: "Сводка",
                            children: (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsxs(Flex, { gap: 12, wrap: true, children: [_jsx(Card, { children: _jsx(Statistic, { title: "\u0412\u0441\u0435\u0433\u043E \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u0432 \u043E\u0442\u0447\u0451\u0442\u0435", value: totals.total }) }), _jsx(Card, { children: _jsx(Statistic, { title: "\u0423\u0441\u043F\u0435\u0448\u043D\u043E \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", value: totals.completed }) }), _jsx(Card, { children: _jsx(Statistic, { title: "\u041D\u0435 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E", value: totals.failed }) })] }), report.data && report.data.length > 0 ? (_jsx(Table, { rowKey: "departmentName", dataSource: report.data, columns: [
                                            { title: "Подразделение", dataIndex: "departmentName" },
                                            { title: "Всего", dataIndex: "totalEmployees" },
                                            { title: "Пройдено", dataIndex: "completed" },
                                            { title: "Не пройдено", dataIndex: "failed" }
                                        ] })) : (_jsx(EmptyState, { description: "\u041D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445 \u0437\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434" }))] }))
                        },
                        {
                            key: "overdue",
                            label: "Просроченные",
                            children: (_jsx(Table, { rowKey: "id", dataSource: overdue.data ?? [], columns: [
                                    { title: "Программа", dataIndex: ["program", "title"] },
                                    { title: "Подразделение", dataIndex: ["department", "name"] },
                                    {
                                        title: "Дата",
                                        dataIndex: "briefingDate",
                                        render: (value) => formatDateRu(value)
                                    }
                                ] }))
                        }
                    ] }) })] }));
}
