import { Role } from "@ot/shared";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import type { CreateJournalPayload, JournalItem } from "../api/journals-api";
import { useDepartments } from "../hooks/use-directories";
import { useCreateJournal, useJournals } from "../hooks/use-journals";
import { usePrograms } from "../hooks/use-programs";
import { useUsers } from "../hooks/use-users";
import { formatDateRu } from "../utils/date";
import { getJournalStatusLabel, getProgramStatusLabel, getRoleLabel, journalStatusOptions } from "../utils/ui-labels";

export function BriefingsPage() {
  const [form] = Form.useForm<CreateJournalPayload>();
  const [isModalOpen, setModalOpen] = useState(false);
  const journals = useJournals();
  const createJournal = useCreateJournal();
  const programsQuery = usePrograms();
  const usersQuery = useUsers();
  const departmentsQuery = useDepartments();
  const canManageJournals = useCan("journals:write");
  const [search, setSearch] = useState("");

  const programsById = useMemo(
    () =>
      Object.fromEntries((programsQuery.data ?? []).map((program) => [program.id, program.title])),
    [programsQuery.data]
  );

  const programOptions = useMemo(
    () =>
      (programsQuery.data ?? []).map((program) => ({
        value: program.id,
        label: `${program.title} (${getProgramStatusLabel(program.status)})`
      })),
    [programsQuery.data]
  );

  const instructorOptions = useMemo(
    () =>
      (usersQuery.data ?? [])
        .filter((user) => user.role === Role.Inspector || user.role === Role.Admin)
        .map((user) => ({
          value: user.id,
          label: `${user.fullName} (${getRoleLabel(user.role)})`
        })),
    [usersQuery.data]
  );

  const departmentOptions = useMemo(
    () =>
      (departmentsQuery.data ?? []).map((department) => ({
        value: department.id,
        label: department.name
      })),
    [departmentsQuery.data]
  );

  const columns = useMemo<ColumnsType<JournalItem>>(
    () => [
      {
        title: "Дата инструктажа",
        dataIndex: "briefingDate",
        render: (value: string) => formatDateRu(value)
      },
      {
        title: "Статус",
        dataIndex: "status",
        render: (value: string) => <Tag color={value === "Completed" ? "green" : "blue"}>{getJournalStatusLabel(value)}</Tag>
      },
      {
        title: "Программа",
        dataIndex: "programId",
        render: (value?: string) => (value ? programsById[value] ?? value : "—")
      }
    ],
    [programsById]
  );

  const filteredJournals = useMemo(() => {
    const source = journals.data ?? [];
    const normalized = search.trim().toLowerCase();
    if (!normalized) {
      return source;
    }
    return source.filter((item) => {
      const title = item.programId ? programsById[item.programId] ?? item.programId : "";
      return title.toLowerCase().includes(normalized);
    });
  }, [journals.data, programsById, search]);

  const submit = async () => {
    const values = await form.validateFields();
    await createJournal.mutateAsync(values);
    setModalOpen(false);
    form.resetFields();
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader
        title="Журналы инструктажей"
        description="Планирование и проведение инструктажей"
        actionText={canManageJournals ? "Создать журнал" : undefined}
        onActionClick={canManageJournals ? () => setModalOpen(true) : undefined}
      />
      <Input.Search
        placeholder="Поиск по программе"
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        allowClear
      />
      <PageState isLoading={journals.isLoading} isError={journals.isError} errorTitle="Не удалось загрузить журналы">
        {filteredJournals.length > 0 ? (
          <EntityTable columns={columns} data={filteredJournals} />
        ) : (
          <EmptyState description="Журналы пока не созданы" />
        )}
      </PageState>
      <EntityFormModal
        title="Новый журнал"
        open={isModalOpen}
        onCancel={() => setModalOpen(false)}
        onSubmit={submit}
        confirmLoading={createJournal.isPending}
      >
        <Form layout="vertical" form={form} preserve={false} initialValues={{ status: "Planned" }}>
          <Form.Item label="Программа" name="programId" rules={[{ required: true, message: "Выберите программу" }]}>
            <Select
              options={programOptions}
              loading={programsQuery.isLoading}
              disabled={programsQuery.isLoading || programsQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите программу"
              notFoundContent="Программы не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Дата инструктажа" name="briefingDate" rules={[{ required: true, message: "Укажите дату в формате YYYY-MM-DD" }]}>
            <Input placeholder="2026-05-16" />
          </Form.Item>
          <Form.Item label="Инструктор" name="instructorId" rules={[{ required: true, message: "Выберите инструктора" }]}>
            <Select
              options={instructorOptions}
              loading={usersQuery.isLoading}
              disabled={usersQuery.isLoading || usersQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите инструктора"
              notFoundContent="Инструкторы не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Подразделение" name="departmentId" rules={[{ required: true, message: "Выберите подразделение" }]}>
            <Select
              options={departmentOptions}
              loading={departmentsQuery.isLoading}
              disabled={departmentsQuery.isLoading || departmentsQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите подразделение"
              notFoundContent="Подразделения не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Статус" name="status" rules={[{ required: true, message: "Выберите статус" }]}>
            <Select
              options={journalStatusOptions}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите статус"
              notFoundContent="Статусы не найдены"
            />
          </Form.Item>
          {createJournal.isError ? <Button danger block>Не удалось создать журнал</Button> : null}
        </Form>
      </EntityFormModal>
    </Space>
  );
}
