import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import { Role, UserStatus } from "@ot/shared";
import { useMemo, useState } from "react";
import { useDepartments, usePositions } from "../hooks/use-directories";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useCreateUser, useUsers } from "../hooks/use-users";
import { getRoleLabel, getUserStatusLabel, roleOptions, userStatusOptions } from "../utils/ui-labels";
export function UsersPage() {
    const [form] = Form.useForm();
    const [isModalOpen, setModalOpen] = useState(false);
    const usersQuery = useUsers();
    const createUserMutation = useCreateUser();
    const departmentsQuery = useDepartments();
    const positionsQuery = usePositions();
    const canManageUsers = useCan("users:write");
    const [search, setSearch] = useState("");
    const departmentOptions = useMemo(() => (departmentsQuery.data ?? []).map((department) => ({
        value: department.id,
        label: department.name
    })), [departmentsQuery.data]);
    const positionOptions = useMemo(() => (positionsQuery.data ?? []).map((position) => ({
        value: position.id,
        label: position.name
    })), [positionsQuery.data]);
    const columns = useMemo(() => [
        { title: "ФИО", dataIndex: "fullName" },
        { title: "Эл. почта", dataIndex: "email" },
        {
            title: "Роль",
            dataIndex: "role",
            render: (value) => _jsx(Tag, { color: value === Role.Admin ? "red" : "blue", children: getRoleLabel(value) })
        },
        {
            title: "Статус",
            dataIndex: "status",
            render: (value) => _jsx(Tag, { color: value === UserStatus.Active ? "green" : "default", children: getUserStatusLabel(value) })
        }
    ], []);
    const filteredUsers = useMemo(() => {
        const source = usersQuery.data ?? [];
        const normalized = search.trim().toLowerCase();
        if (!normalized) {
            return source;
        }
        return source.filter((item) => item.fullName.toLowerCase().includes(normalized) ||
            item.email.toLowerCase().includes(normalized));
    }, [search, usersQuery.data]);
    const openCreateModal = () => {
        form.setFieldsValue({
            role: Role.Employee,
            status: UserStatus.Active
        });
        setModalOpen(true);
    };
    const handleSubmit = async () => {
        const values = await form.validateFields();
        await createUserMutation.mutateAsync(values);
        setModalOpen(false);
        form.resetFields();
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0438", description: "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430\u043C\u0438 \u0438 \u0440\u043E\u043B\u044F\u043C\u0438 \u0434\u043E\u0441\u0442\u0443\u043F\u0430", actionText: canManageUsers ? "Добавить" : undefined, onActionClick: canManageUsers ? openCreateModal : undefined }), _jsx(Input.Search, { placeholder: "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0424\u0418\u041E \u0438\u043B\u0438 email", value: search, onChange: (event) => setSearch(event.target.value), allowClear: true }), _jsx(PageState, { isLoading: usersQuery.isLoading, isError: usersQuery.isError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439", children: filteredUsers.length > 0 ? (_jsx(EntityTable, { columns: columns, data: filteredUsers })) : (_jsx(EmptyState, { description: "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0438 \u043F\u043E\u043A\u0430 \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u044B" })) }), _jsx(EntityFormModal, { title: "\u041D\u043E\u0432\u044B\u0439 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C", open: isModalOpen, onCancel: () => setModalOpen(false), onSubmit: handleSubmit, confirmLoading: createUserMutation.isPending, children: _jsxs(Form, { form: form, layout: "vertical", preserve: false, children: [_jsx(Form.Item, { label: "\u0424\u0418\u041E", name: "fullName", rules: [{ required: true, message: "Введите ФИО" }], children: _jsx(Input, { placeholder: "\u0418\u0432\u0430\u043D\u043E\u0432 \u0418\u0432\u0430\u043D \u0418\u0432\u0430\u043D\u043E\u0432\u0438\u0447" }) }), _jsx(Form.Item, { label: "\u042D\u043B. \u043F\u043E\u0447\u0442\u0430", name: "email", rules: [{ required: true, message: "Введите email" }], children: _jsx(Input, { placeholder: "employee@example.com" }) }), _jsx(Form.Item, { label: "\u0420\u043E\u043B\u044C", name: "role", rules: [{ required: true, message: "Выберите роль" }], children: _jsx(Select, { options: roleOptions, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u043E\u043B\u044C", notFoundContent: "\u0420\u043E\u043B\u0438 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B" }) }), _jsx(Form.Item, { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", name: "departmentId", rules: [{ required: true, message: "Выберите подразделение" }], children: _jsx(Select, { options: departmentOptions, loading: departmentsQuery.isLoading, disabled: departmentsQuery.isLoading || departmentsQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", notFoundContent: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", name: "positionId", rules: [{ required: true, message: "Выберите должность" }], children: _jsx(Select, { options: positionOptions, loading: positionsQuery.isLoading, disabled: positionsQuery.isLoading || positionsQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u044C", notFoundContent: "\u0414\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0414\u0430\u0442\u0430 \u043F\u0440\u0438\u0451\u043C\u0430", name: "hireDate", rules: [{ required: true, message: "Укажите дату в формате YYYY-MM-DD" }], children: _jsx(Input, { placeholder: "2026-05-16" }) }), _jsx(Form.Item, { label: "\u0421\u0442\u0430\u0442\u0443\u0441", name: "status", rules: [{ required: true, message: "Выберите статус" }], children: _jsx(Select, { options: userStatusOptions, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u0430\u0442\u0443\u0441", notFoundContent: "\u0421\u0442\u0430\u0442\u0443\u0441\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B" }) }), createUserMutation.isError ? _jsx(Button, { danger: true, block: true, children: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F" }) : null] }) })] }));
}
