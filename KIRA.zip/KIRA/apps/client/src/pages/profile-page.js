import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Avatar, Card, Col, List, Row, Space, Tag, Typography } from "antd";
import { UserOutlined } from "@ant-design/icons";
import { PageHeader } from "../components/common/page-header";
import { useEmployeeHistory } from "../hooks/use-reports";
import { formatDateRu } from "../utils/date";
import { useAuthStore } from "../store/auth-store";
import { getRoleLabel } from "../utils/ui-labels";
export function ProfilePage() {
    const user = useAuthStore((state) => state.user);
    const historyQuery = useEmployeeHistory(user?.id);
    const history = historyQuery.data?.records ?? [];
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u041B\u0438\u0447\u043D\u044B\u0439 \u043A\u0430\u0431\u0438\u043D\u0435\u0442", description: "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0438 \u0441\u0442\u0430\u0442\u0443\u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430" }), _jsxs(Row, { gutter: [16, 16], children: [_jsx(Col, { xs: 24, lg: 8, children: _jsx(Card, { children: _jsxs(Space, { direction: "vertical", size: 8, children: [_jsx(Avatar, { size: 64, icon: _jsx(UserOutlined, {}) }), _jsx(Typography.Title, { level: 4, style: { margin: 0 }, children: user?.fullName ?? "Неизвестно" }), _jsx(Typography.Text, { children: user?.email ?? "Неизвестно" }), _jsx(Tag, { color: "blue", children: getRoleLabel(user?.role) })] }) }) }), _jsx(Col, { xs: 24, lg: 16, children: _jsx(Card, { title: "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", children: _jsx(List, { dataSource: history, renderItem: (item) => (_jsxs(List.Item, { children: [_jsx(List.Item.Meta, { title: item.journal.program.title, description: `Дата: ${formatDateRu(item.journal.briefingDate)}` }), _jsx(Tag, { color: item.signedAt ? "green" : "default", children: item.signedAt ? "Подписано" : "Ожидает подпись" })] })) }) }) })] })] }));
}
