import { DownloadOutlined } from "@ant-design/icons";
import { Button, Card, DatePicker, Flex, Space, Statistic, Table, Tabs } from "antd";
import dayjs from "dayjs";
import { useMemo, useState } from "react";
import { reportsApi } from "../api/reports-api";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { downloadCompletionCsv, useCompletionReport, useOverdueBriefings } from "../hooks/use-reports";
import { formatDateRu, getCurrentYearRange, toIsoDate } from "../utils/date";

export function ReportsPage() {
  const defaultRange = getCurrentYearRange();
  const [from, setFrom] = useState(defaultRange.from);
  const [to, setTo] = useState(defaultRange.to);
  const report = useCompletionReport(from, to);
  const overdue = useOverdueBriefings();

  const totals = useMemo(
    () =>
      (report.data ?? []).reduce(
        (acc, item) => {
          acc.total += item.totalEmployees;
          acc.completed += item.completed;
          acc.failed += item.failed;
          return acc;
        },
        { total: 0, completed: 0, failed: 0 }
      ),
    [report.data]
  );

  const exportCsv = () => {
    if (!report.data?.length) {
      return;
    }
    const file = reportsApi.exportCompletionCsv(report.data);
    downloadCompletionCsv(`ot-report-${from}-${to}.csv`, file);
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader title="Отчёты" description="Сводка и просроченные инструктажи" />
      <Flex gap={12} wrap align="center">
        <DatePicker
          value={dayjs(from)}
          format="DD.MM.YYYY"
          onChange={(value) => {
            if (value) setFrom(toIsoDate(value.toDate()));
          }}
        />
        <DatePicker
          value={dayjs(to)}
          format="DD.MM.YYYY"
          onChange={(value) => {
            if (value) setTo(toIsoDate(value.toDate()));
          }}
        />
        <Button icon={<DownloadOutlined />} onClick={exportCsv}>
          Экспорт CSV
        </Button>
      </Flex>
      <PageState isLoading={report.isLoading} isError={report.isError} errorTitle="Не удалось загрузить отчёт">
        <Tabs
          items={[
            {
              key: "summary",
              label: "Сводка",
              children: (
                <Space direction="vertical" size={16} style={{ width: "100%" }}>
                  <Flex gap={12} wrap>
                    <Card>
                      <Statistic title="Всего сотрудников в отчёте" value={totals.total} />
                    </Card>
                    <Card>
                      <Statistic title="Успешно пройдено" value={totals.completed} />
                    </Card>
                    <Card>
                      <Statistic title="Не пройдено" value={totals.failed} />
                    </Card>
                  </Flex>
                  {report.data && report.data.length > 0 ? (
                    <Table
                      rowKey="departmentName"
                      dataSource={report.data}
                      columns={[
                        { title: "Подразделение", dataIndex: "departmentName" },
                        { title: "Всего", dataIndex: "totalEmployees" },
                        { title: "Пройдено", dataIndex: "completed" },
                        { title: "Не пройдено", dataIndex: "failed" }
                      ]}
                    />
                  ) : (
                    <EmptyState description="Нет данных за выбранный период" />
                  )}
                </Space>
              )
            },
            {
              key: "overdue",
              label: "Просроченные",
              children: (
                <Table
                  rowKey="id"
                  dataSource={overdue.data ?? []}
                  columns={[
                    { title: "Программа", dataIndex: ["program", "title"] },
                    { title: "Подразделение", dataIndex: ["department", "name"] },
                    {
                      title: "Дата",
                      dataIndex: "briefingDate",
                      render: (value: string) => formatDateRu(value)
                    }
                  ]}
                />
              )
            }
          ]}
        />
      </PageState>
    </Space>
  );
}
