import { Button, Form, Input, Select, Space, Tag } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import type { CreateProgramPayload, ProgramItem } from "../api/programs-api";
import { useBriefingTypes } from "../hooks/use-directories";
import { useCreateProgram, usePrograms } from "../hooks/use-programs";
import { getProgramStatusLabel, programStatusOptions } from "../utils/ui-labels";

export function ProgramsPage() {
  const [form] = Form.useForm<CreateProgramPayload>();
  const [isModalOpen, setModalOpen] = useState(false);
  const programs = usePrograms();
  const createProgram = useCreateProgram();
  const briefingTypesQuery = useBriefingTypes();
  const canManagePrograms = useCan("programs:write");
  const [search, setSearch] = useState("");

  const briefingTypeOptions = useMemo(
    () =>
      (briefingTypesQuery.data ?? []).map((item) => ({
        value: item.id,
        label: item.name
      })),
    [briefingTypesQuery.data]
  );

  const columns = useMemo<ColumnsType<ProgramItem>>(
    () => [
      { title: "Название", dataIndex: "title" },
      {
        title: "Статус",
        dataIndex: "status",
        render: (value: string) => <Tag color={value === "Published" ? "green" : "default"}>{getProgramStatusLabel(value)}</Tag>
      },
      {
        title: "Вопросы",
        render: (_, item) => item.questions?.length ?? 0
      }
    ],
    []
  );

  const filteredPrograms = useMemo(() => {
    const source = programs.data ?? [];
    const normalized = search.trim().toLowerCase();
    if (!normalized) {
      return source;
    }
    return source.filter((item) => item.title.toLowerCase().includes(normalized));
  }, [programs.data, search]);

  const submit = async () => {
    const values = await form.validateFields();
    const payload: CreateProgramPayload = {
      ...values,
      questions: [
        {
          text: values.questions?.[0]?.text ?? "Контрольный вопрос",
          order: 1,
          isRequired: true
        }
      ]
    };
    await createProgram.mutateAsync(payload);
    setModalOpen(false);
    form.resetFields();
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader
        title="Программы инструктажей"
        description="Каталог программ и тестовых вопросов"
        actionText={canManagePrograms ? "Создать программу" : undefined}
        onActionClick={canManagePrograms ? () => setModalOpen(true) : undefined}
      />
      <Input.Search
        placeholder="Поиск программы"
        value={search}
        onChange={(event) => setSearch(event.target.value)}
        allowClear
      />
      <PageState isLoading={programs.isLoading} isError={programs.isError} errorTitle="Не удалось загрузить программы">
        {filteredPrograms.length > 0 ? (
          <EntityTable columns={columns} data={filteredPrograms} />
        ) : (
          <EmptyState description="Программы пока не добавлены" />
        )}
      </PageState>
      <EntityFormModal
        title="Новая программа"
        open={isModalOpen}
        onCancel={() => setModalOpen(false)}
        onSubmit={submit}
        confirmLoading={createProgram.isPending}
      >
        <Form layout="vertical" form={form} preserve={false}>
          <Form.Item label="Название" name="title" rules={[{ required: true, message: "Введите название" }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Описание" name="description">
            <Input.TextArea rows={3} />
          </Form.Item>
          <Form.Item label="Вид инструктажа" name="briefingTypeId" rules={[{ required: true, message: "Выберите вид инструктажа" }]}>
            <Select
              options={briefingTypeOptions}
              loading={briefingTypesQuery.isLoading}
              disabled={briefingTypesQuery.isLoading || briefingTypesQuery.isError}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите вид инструктажа"
              notFoundContent="Виды инструктажа не найдены"
              allowClear
            />
          </Form.Item>
          <Form.Item label="Статус" name="status" initialValue="Draft" rules={[{ required: true, message: "Выберите статус" }]}>
            <Select
              options={programStatusOptions}
              showSearch
              optionFilterProp="label"
              placeholder="Выберите статус"
              notFoundContent="Статусы не найдены"
            />
          </Form.Item>
          <Form.Item label="Первый вопрос" name={["questions", 0, "text"]} rules={[{ required: true, message: "Введите вопрос" }]}>
            <Input />
          </Form.Item>
          {createProgram.isError ? <Button danger block>Не удалось создать программу</Button> : null}
        </Form>
      </EntityFormModal>
    </Space>
  );
}
