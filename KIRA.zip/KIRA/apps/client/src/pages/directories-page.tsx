import { Button, Form, Input, InputNumber, Space, Tabs } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useBriefingTypes, useCreateBriefingType, useCreateDepartment, useCreatePosition, useDepartments, usePositions } from "../hooks/use-directories";
import type { DirectoryItem } from "../api/directories-api";

interface DirectoryRow extends DirectoryItem {
  extra: string;
}

export function DirectoriesPage() {
  const [form] = Form.useForm();
  const [activeTab, setActiveTab] = useState("departments");
  const [isModalOpen, setModalOpen] = useState(false);
  const departments = useDepartments();
  const positions = usePositions();
  const briefingTypes = useBriefingTypes();
  const createDepartment = useCreateDepartment();
  const createPosition = useCreatePosition();
  const createBriefingType = useCreateBriefingType();
  const canManageDirectories = useCan("directories:write");

  const columns = useMemo<ColumnsType<DirectoryRow>>(
    () => [
      { title: "Название", dataIndex: "name" },
      { title: "Код / периодичность", dataIndex: "extra" }
    ],
    []
  );

  const dataByTab: Record<string, DirectoryRow[]> = {
    departments: (departments.data ?? []).map((item) => ({ ...item, extra: item.code ?? "-" })),
    positions: (positions.data ?? []).map((item) => ({ ...item, extra: "-" })),
    briefingTypes: (briefingTypes.data ?? []).map((item) => ({ ...item, extra: item.periodicityMonths ? `${item.periodicityMonths} мес.` : "-" }))
  };

  const loadingByTab: Record<string, boolean> = {
    departments: departments.isLoading,
    positions: positions.isLoading,
    briefingTypes: briefingTypes.isLoading
  };

  const errorByTab: Record<string, boolean> = {
    departments: departments.isError,
    positions: positions.isError,
    briefingTypes: briefingTypes.isError
  };

  const currentData = dataByTab[activeTab] ?? [];
  const isCurrentLoading = loadingByTab[activeTab] ?? false;
  const isCurrentError = errorByTab[activeTab] ?? false;

  const submitForm = async () => {
    const values = await form.validateFields();
    if (activeTab === "departments") {
      await createDepartment.mutateAsync(values as { name: string; code: string });
    }
    if (activeTab === "positions") {
      await createPosition.mutateAsync(values as { name: string });
    }
    if (activeTab === "briefingTypes") {
      await createBriefingType.mutateAsync(values as { name: string; periodicityMonths: number });
    }
    setModalOpen(false);
    form.resetFields();
  };

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader
        title="Справочники"
        description="Подразделения, должности и виды инструктажей"
        actionText={canManageDirectories ? "Добавить запись" : undefined}
        onActionClick={canManageDirectories ? () => setModalOpen(true) : undefined}
      />
      <Tabs
        activeKey={activeTab}
        onChange={(key) => setActiveTab(key)}
        items={[
          { key: "departments", label: "Подразделения" },
          { key: "positions", label: "Должности" },
          { key: "briefingTypes", label: "Виды инструктажей" }
        ]}
      />
      <PageState isLoading={isCurrentLoading} isError={isCurrentError} errorTitle="Не удалось загрузить справочник">
        {currentData.length > 0 ? (
          <EntityTable columns={columns} data={currentData} />
        ) : (
          <EmptyState description="В этом справочнике пока нет записей" />
        )}
      </PageState>
      <EntityFormModal
        title="Новая запись справочника"
        open={isModalOpen}
        onCancel={() => setModalOpen(false)}
        onSubmit={submitForm}
        confirmLoading={createDepartment.isPending || createPosition.isPending || createBriefingType.isPending}
      >
        <Form layout="vertical" form={form} preserve={false}>
          <Form.Item label="Название" name="name" rules={[{ required: true, message: "Введите название" }]}>
            <Input />
          </Form.Item>
          {activeTab === "departments" ? (
            <Form.Item label="Код" name="code" rules={[{ required: true, message: "Введите код" }]}>
              <Input />
            </Form.Item>
          ) : null}
          {activeTab === "briefingTypes" ? (
            <Form.Item
              label="Периодичность (месяцы)"
              name="periodicityMonths"
              rules={[{ required: true, message: "Укажите периодичность" }]}
            >
              <InputNumber min={1} max={36} style={{ width: "100%" }} />
            </Form.Item>
          ) : null}
          {createDepartment.isError || createPosition.isError || createBriefingType.isError ? (
            <Button danger block>Не удалось сохранить запись</Button>
          ) : null}
        </Form>
      </EntityFormModal>
    </Space>
  );
}
