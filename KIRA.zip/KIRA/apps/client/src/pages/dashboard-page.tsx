import { CalendarOutlined, CheckCircleOutlined, ClockCircleOutlined } from "@ant-design/icons";
import { Card, Col, List, Row, Space, Statistic, Tag, Typography } from "antd";
import { PageHeader } from "../components/common/page-header";
import { useOverdueBriefings, useReportsSummary, useUpcomingBriefings } from "../hooks/use-reports";
import { formatDateRu } from "../utils/date";

export function DashboardPage() {
  const summary = useReportsSummary();
  const upcoming = useUpcomingBriefings(14);
  const overdue = useOverdueBriefings();
  const upcomingItems = upcoming.data ?? [];
  const overdueItems = overdue.data ?? [];

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <PageHeader title="Дашборд" description={`Сегодня: ${formatDateRu(new Date())}`} />
      <Row gutter={[16, 16]}>
        <Col xs={24} md={8}>
          <Card>
            <Statistic title="Запланировано на 14 дней" value={upcomingItems.length} prefix={<ClockCircleOutlined />} />
          </Card>
        </Col>
        <Col xs={24} md={8}>
          <Card>
            <Statistic title="Просрочено" value={overdueItems.length} prefix={<CalendarOutlined />} />
          </Card>
        </Col>
        <Col xs={24} md={8}>
          <Card>
            <Statistic title="Всего тестов" value={summary.data?.tests ?? 0} prefix={<CheckCircleOutlined />} />
          </Card>
        </Col>
      </Row>
      <Row gutter={[16, 16]}>
        <Col xs={24} lg={12}>
          <Card title="Ближайшие инструктажи">
            <List
              dataSource={upcomingItems}
              renderItem={(item) => (
                <List.Item>
                  <List.Item.Meta
                    title={item.program.title}
                    description={`Дата: ${formatDateRu(item.briefingDate)}`}
                  />
                  <Tag color="blue">{item.department.name}</Tag>
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card title="Просроченные">
            <List
              dataSource={overdueItems}
              renderItem={(item) => (
                <List.Item>
                  <List.Item.Meta
                    title={item.program.title}
                    description={<Typography.Text type="danger">Срок: {formatDateRu(item.briefingDate)}</Typography.Text>}
                  />
                  <Tag color="red">Требует действий</Tag>
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>
    </Space>
  );
}
