import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useJournals } from "../hooks/use-journals";
import { usePrograms } from "../hooks/use-programs";
import { useSubmitTest, useTestResults } from "../hooks/use-test-results";
import { getJournalStatusLabel, getTestResultStatusLabel } from "../utils/ui-labels";
import { useAuthStore } from "../store/auth-store";
export function TestsPage() {
    const [form] = Form.useForm();
    const [isModalOpen, setModalOpen] = useState(false);
    const results = useTestResults();
    const submitTest = useSubmitTest();
    const journalsQuery = useJournals();
    const programsQuery = usePrograms();
    const canSubmitTest = useCan("tests:submit");
    const currentUser = useAuthStore((state) => state.user);
    const journalOptions = useMemo(() => (journalsQuery.data ?? []).map((journal) => ({
        value: journal.id,
        label: `${journal.id.slice(0, 8)}... (${getJournalStatusLabel(journal.status)})`
    })), [journalsQuery.data]);
    const columns = useMemo(() => [
        {
            title: "Сотрудник",
            dataIndex: "employeeId",
            render: (value) => value && value === currentUser?.id
                ? currentUser.fullName
                : (value ?? "—")
        },
        {
            title: "Балл",
            dataIndex: "score",
            render: (value) => `${value}%`
        },
        {
            title: "Статус",
            dataIndex: "status",
            render: (value) => _jsx(Tag, { color: value === "Passed" ? "green" : "red", children: getTestResultStatusLabel(value) })
        }
    ], [currentUser]);
    const submit = async () => {
        const values = await form.validateFields();
        const selectedJournal = (journalsQuery.data ?? []).find((journal) => journal.id === values.journalId);
        const selectedProgram = (programsQuery.data ?? []).find((program) => program.id === selectedJournal?.programId);
        const questionId = selectedProgram?.questions?.[0]?.id ?? "00000000-0000-0000-0000-000000000001";
        await submitTest.mutateAsync({
            journalId: values.journalId,
            answers: [
                {
                    questionId,
                    answer: values.answers?.[0]?.answer ?? "Да"
                }
            ]
        });
        setModalOpen(false);
        form.resetFields();
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F", description: "\u041E\u043D\u043B\u0430\u0439\u043D-\u0442\u0435\u0441\u0442 \u043F\u043E\u0441\u043B\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", actionText: canSubmitTest ? "Пройти тест" : undefined, onActionClick: canSubmitTest ? () => setModalOpen(true) : undefined }), _jsx(PageState, { isLoading: results.isLoading, isError: results.isError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F", children: results.data && results.data.length > 0 ? (_jsx(EntityTable, { columns: columns, data: results.data })) : (_jsx(EmptyState, { description: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u043A\u0430 \u043D\u0435\u0442" })) }), _jsx(EntityFormModal, { title: "\u041F\u0440\u043E\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u0442\u0435\u0441\u0442\u0430", open: isModalOpen, onCancel: () => setModalOpen(false), onSubmit: submit, confirmLoading: submitTest.isPending, children: _jsxs(Form, { layout: "vertical", form: form, preserve: false, children: [_jsx(Form.Item, { label: "\u0416\u0443\u0440\u043D\u0430\u043B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", name: "journalId", rules: [{ required: true, message: "Выберите журнал" }], children: _jsx(Select, { options: journalOptions, loading: journalsQuery.isLoading, disabled: journalsQuery.isLoading || journalsQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0436\u0443\u0440\u043D\u0430\u043B", notFoundContent: "\u0416\u0443\u0440\u043D\u0430\u043B\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A", children: _jsx(Input, { value: currentUser?.fullName ?? "—", disabled: true }) }), _jsx(Form.Item, { label: "\u0412\u0430\u0448 \u043E\u0442\u0432\u0435\u0442", name: ["answers", 0, "answer"], rules: [{ required: true, message: "Введите ответ" }], children: _jsx(Input, { placeholder: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u0432\u043E\u043F\u0440\u043E\u0441" }) }), submitTest.isError ? _jsx(Button, { danger: true, block: true, children: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442" }) : null] }) })] }));
}
