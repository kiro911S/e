import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { LogoutOutlined, MoonOutlined, SunOutlined } from "@ant-design/icons";
import { Breadcrumb, Button, Layout, Menu, Space, Switch, theme, Typography } from "antd";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { authApi } from "../api/auth-api";
import { buildMenuItems, getRouteTitle } from "../app/navigation/menu-builder";
import { useThemeMode } from "../app/providers/antd-provider";
import { useAuthStore } from "../store/auth-store";
const { Header, Content, Sider } = Layout;
export function PageShell() {
    const { logout, user } = useAuthStore();
    const navigate = useNavigate();
    const location = useLocation();
    const { isDarkMode, toggleThemeMode } = useThemeMode();
    const { token } = theme.useToken();
    const menuItems = buildMenuItems(user?.role);
    const currentPath = location.pathname;
    const currentTitle = getRouteTitle(currentPath);
    const onLogout = () => {
        void authApi.logout().catch(() => undefined);
        logout();
        navigate("/login", { replace: true });
    };
    return (_jsxs(Layout, { style: { minHeight: "100vh" }, children: [_jsxs(Sider, { breakpoint: "lg", collapsedWidth: 64, children: [_jsx("div", { style: { color: "#fff", fontSize: 18, fontWeight: 600, padding: "16px 20px" }, children: "KIRA OT" }), _jsx(Menu, { theme: "dark", mode: "inline", selectedKeys: [currentPath], items: menuItems, onClick: ({ key }) => {
                            navigate(String(key));
                        } })] }), _jsxs(Layout, { children: [_jsxs(Header, { style: { display: "flex", alignItems: "center", justifyContent: "space-between", paddingInline: 20 }, children: [_jsx(Typography.Title, { level: 4, style: { margin: 0 }, children: currentTitle }), _jsxs(Space, { children: [_jsx(Typography.Text, { children: user?.fullName ?? "Пользователь" }), _jsx(Switch, { checked: isDarkMode, checkedChildren: _jsx(MoonOutlined, {}), unCheckedChildren: _jsx(SunOutlined, {}), onChange: toggleThemeMode }), _jsx(Button, { icon: _jsx(LogoutOutlined, {}), onClick: onLogout, children: "\u0412\u044B\u0439\u0442\u0438" })] })] }), _jsxs(Content, { style: { margin: 20 }, children: [_jsx(Breadcrumb, { style: { marginBottom: 16 }, items: [
                                    { title: "Главная" },
                                    { title: currentTitle }
                                ] }), _jsx("div", { style: {
                                    padding: 20,
                                    minHeight: 360,
                                    background: token.colorBgContainer,
                                    borderRadius: token.borderRadiusLG
                                }, children: _jsx(Outlet, {}) })] })] })] }));
}
