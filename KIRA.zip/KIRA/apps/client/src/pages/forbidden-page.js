import { jsx as _jsx } from "react/jsx-runtime";
import { Button, Result } from "antd";
import { useNavigate } from "react-router-dom";
export function ForbiddenPage() {
    const navigate = useNavigate();
    return (_jsx(Result, { status: "403", title: "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430", subTitle: "\u0423 \u0432\u0430\u0441 \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u043F\u0440\u0430\u0432 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B.", extra: _jsx(Button, { type: "primary", onClick: () => navigate("/dashboard"), children: "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043D\u0430 \u0434\u0430\u0448\u0431\u043E\u0440\u0434" }) }));
}
