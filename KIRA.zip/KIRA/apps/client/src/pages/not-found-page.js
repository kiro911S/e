import { jsx as _jsx } from "react/jsx-runtime";
import { Button, Result } from "antd";
import { useNavigate } from "react-router-dom";
export function NotFoundPage() {
    const navigate = useNavigate();
    return (_jsx(Result, { status: "404", title: "\u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430", subTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0430\u0434\u0440\u0435\u0441 \u0438\u043B\u0438 \u0432\u0435\u0440\u043D\u0438\u0442\u0435\u0441\u044C \u0432 \u043C\u0435\u043D\u044E.", extra: _jsx(Button, { type: "primary", onClick: () => navigate("/dashboard"), children: "\u041D\u0430 \u0433\u043B\u0430\u0432\u043D\u0443\u044E" }) }));
}
