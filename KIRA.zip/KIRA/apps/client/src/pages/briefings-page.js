import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Role } from "@ot/shared";
import { Button, Form, Input, Select, Space, Tag } from "antd";
import { useMemo, useState } from "react";
import { useCan } from "../app/policy/use-policy";
import { PageHeader } from "../components/common/page-header";
import { EmptyState } from "../components/feedback/empty-state";
import { PageState } from "../components/feedback/page-state";
import { EntityFormModal } from "../components/form/entity-form-modal";
import { EntityTable } from "../components/table/entity-table";
import { useDepartments } from "../hooks/use-directories";
import { useCreateJournal, useJournals } from "../hooks/use-journals";
import { usePrograms } from "../hooks/use-programs";
import { useUsers } from "../hooks/use-users";
import { formatDateRu } from "../utils/date";
import { getJournalStatusLabel, getProgramStatusLabel, getRoleLabel, journalStatusOptions } from "../utils/ui-labels";
export function BriefingsPage() {
    const [form] = Form.useForm();
    const [isModalOpen, setModalOpen] = useState(false);
    const journals = useJournals();
    const createJournal = useCreateJournal();
    const programsQuery = usePrograms();
    const usersQuery = useUsers();
    const departmentsQuery = useDepartments();
    const canManageJournals = useCan("journals:write");
    const [search, setSearch] = useState("");
    const programsById = useMemo(() => Object.fromEntries((programsQuery.data ?? []).map((program) => [program.id, program.title])), [programsQuery.data]);
    const programOptions = useMemo(() => (programsQuery.data ?? []).map((program) => ({
        value: program.id,
        label: `${program.title} (${getProgramStatusLabel(program.status)})`
    })), [programsQuery.data]);
    const instructorOptions = useMemo(() => (usersQuery.data ?? [])
        .filter((user) => user.role === Role.Inspector || user.role === Role.Admin)
        .map((user) => ({
        value: user.id,
        label: `${user.fullName} (${getRoleLabel(user.role)})`
    })), [usersQuery.data]);
    const departmentOptions = useMemo(() => (departmentsQuery.data ?? []).map((department) => ({
        value: department.id,
        label: department.name
    })), [departmentsQuery.data]);
    const columns = useMemo(() => [
        {
            title: "Дата инструктажа",
            dataIndex: "briefingDate",
            render: (value) => formatDateRu(value)
        },
        {
            title: "Статус",
            dataIndex: "status",
            render: (value) => _jsx(Tag, { color: value === "Completed" ? "green" : "blue", children: getJournalStatusLabel(value) })
        },
        {
            title: "Программа",
            dataIndex: "programId",
            render: (value) => (value ? programsById[value] ?? value : "—")
        }
    ], [programsById]);
    const filteredJournals = useMemo(() => {
        const source = journals.data ?? [];
        const normalized = search.trim().toLowerCase();
        if (!normalized) {
            return source;
        }
        return source.filter((item) => {
            const title = item.programId ? programsById[item.programId] ?? item.programId : "";
            return title.toLowerCase().includes(normalized);
        });
    }, [journals.data, programsById, search]);
    const submit = async () => {
        const values = await form.validateFields();
        await createJournal.mutateAsync(values);
        setModalOpen(false);
        form.resetFields();
    };
    return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(PageHeader, { title: "\u0416\u0443\u0440\u043D\u0430\u043B\u044B \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", description: "\u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0435\u0439", actionText: canManageJournals ? "Создать журнал" : undefined, onActionClick: canManageJournals ? () => setModalOpen(true) : undefined }), _jsx(Input.Search, { placeholder: "\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435", value: search, onChange: (event) => setSearch(event.target.value), allowClear: true }), _jsx(PageState, { isLoading: journals.isLoading, isError: journals.isError, errorTitle: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0436\u0443\u0440\u043D\u0430\u043B\u044B", children: filteredJournals.length > 0 ? (_jsx(EntityTable, { columns: columns, data: filteredJournals })) : (_jsx(EmptyState, { description: "\u0416\u0443\u0440\u043D\u0430\u043B\u044B \u043F\u043E\u043A\u0430 \u043D\u0435 \u0441\u043E\u0437\u0434\u0430\u043D\u044B" })) }), _jsx(EntityFormModal, { title: "\u041D\u043E\u0432\u044B\u0439 \u0436\u0443\u0440\u043D\u0430\u043B", open: isModalOpen, onCancel: () => setModalOpen(false), onSubmit: submit, confirmLoading: createJournal.isPending, children: _jsxs(Form, { layout: "vertical", form: form, preserve: false, initialValues: { status: "Planned" }, children: [_jsx(Form.Item, { label: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430", name: "programId", rules: [{ required: true, message: "Выберите программу" }], children: _jsx(Select, { options: programOptions, loading: programsQuery.isLoading, disabled: programsQuery.isLoading || programsQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443", notFoundContent: "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0414\u0430\u0442\u0430 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u0430\u0436\u0430", name: "briefingDate", rules: [{ required: true, message: "Укажите дату в формате YYYY-MM-DD" }], children: _jsx(Input, { placeholder: "2026-05-16" }) }), _jsx(Form.Item, { label: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440", name: "instructorId", rules: [{ required: true, message: "Выберите инструктора" }], children: _jsx(Select, { options: instructorOptions, loading: usersQuery.isLoading, disabled: usersQuery.isLoading || usersQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u0430", notFoundContent: "\u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", name: "departmentId", rules: [{ required: true, message: "Выберите подразделение" }], children: _jsx(Select, { options: departmentOptions, loading: departmentsQuery.isLoading, disabled: departmentsQuery.isLoading || departmentsQuery.isError, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435", notFoundContent: "\u041F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B", allowClear: true }) }), _jsx(Form.Item, { label: "\u0421\u0442\u0430\u0442\u0443\u0441", name: "status", rules: [{ required: true, message: "Выберите статус" }], children: _jsx(Select, { options: journalStatusOptions, showSearch: true, optionFilterProp: "label", placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u0430\u0442\u0443\u0441", notFoundContent: "\u0421\u0442\u0430\u0442\u0443\u0441\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B" }) }), createJournal.isError ? _jsx(Button, { danger: true, block: true, children: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0437\u0434\u0430\u0442\u044C \u0436\u0443\u0440\u043D\u0430\u043B" }) : null] }) })] }));
}
