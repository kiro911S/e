import { Role } from "@ot/shared";
import { create } from "zustand";

interface AuthUser {
  id: string;
  fullName: string;
  email: string;
  role: Role;
}

interface AuthState {
  token: string | null;
  user: AuthUser | null;
  isAuthenticated: boolean;
  isBootstrapping: boolean;
  setAuth: (payload: { token: string; user: AuthUser }) => void;
  finishBootstrap: () => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token: null,
  user: null,
  isAuthenticated: false,
  isBootstrapping: true,
  setAuth: ({ token, user }) =>
    set({
      token,
      user,
      isAuthenticated: true,
      isBootstrapping: false
    }),
  finishBootstrap: () =>
    set({
      isBootstrapping: false
    }),
  logout: () =>
    set({
      token: null,
      user: null,
      isAuthenticated: false,
      isBootstrapping: false
    })
}));
