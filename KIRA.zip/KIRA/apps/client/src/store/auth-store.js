import { create } from "zustand";
export const useAuthStore = create((set) => ({
    token: null,
    user: null,
    isAuthenticated: false,
    isBootstrapping: true,
    setAuth: ({ token, user }) => set({
        token,
        user,
        isAuthenticated: true,
        isBootstrapping: false
    }),
    finishBootstrap: () => set({
        isBootstrapping: false
    }),
    logout: () => set({
        token: null,
        user: null,
        isAuthenticated: false,
        isBootstrapping: false
    })
}));
