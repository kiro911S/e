import { appRouteMeta } from "./route-config";
export function buildMenuItems(role) {
    return appRouteMeta
        .filter((route) => route.showInMenu)
        .filter((route) => !route.roles || (role ? route.roles.includes(role) : false))
        .map((route) => ({
        key: route.path,
        label: route.title,
        icon: route.icon
    }));
}
export function getRouteTitle(pathname) {
    const found = appRouteMeta.find((route) => pathname.startsWith(route.path));
    return found?.title ?? "Страница";
}
