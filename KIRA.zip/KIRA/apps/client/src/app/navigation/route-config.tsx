import { AuditOutlined, BookOutlined, DashboardOutlined, FileTextOutlined, ProfileOutlined, ReadOutlined, TeamOutlined } from "@ant-design/icons";
import { Role } from "@ot/shared";
import type { ReactNode } from "react";

export interface AppRouteMeta {
  key: string;
  path: string;
  title: string;
  icon?: ReactNode;
  roles?: Role[];
  showInMenu: boolean;
}

export const appRouteMeta: AppRouteMeta[] = [
  {
    key: "dashboard",
    path: "/dashboard",
    title: "Дашборд",
    icon: <DashboardOutlined />,
    showInMenu: true
  },
  {
    key: "programs",
    path: "/programs",
    title: "Программы",
    icon: <BookOutlined />,
    showInMenu: true
  },
  {
    key: "briefings",
    path: "/briefings",
    title: "Журналы",
    icon: <ReadOutlined />,
    roles: [Role.Admin, Role.Inspector],
    showInMenu: true
  },
  {
    key: "tests",
    path: "/tests",
    title: "Тестирование",
    icon: <AuditOutlined />,
    showInMenu: true
  },
  {
    key: "reports",
    path: "/reports",
    title: "Отчёты",
    icon: <FileTextOutlined />,
    roles: [Role.Admin, Role.Inspector],
    showInMenu: true
  },
  {
    key: "profile",
    path: "/profile",
    title: "Профиль",
    icon: <ProfileOutlined />,
    showInMenu: true
  },
  {
    key: "adminUsers",
    path: "/admin/users",
    title: "Пользователи",
    icon: <TeamOutlined />,
    roles: [Role.Admin],
    showInMenu: true
  },
  {
    key: "adminDirectories",
    path: "/admin/directories",
    title: "Справочники",
    icon: <BookOutlined />,
    roles: [Role.Admin],
    showInMenu: true
  }
];
