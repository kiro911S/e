import { Role } from "@ot/shared";
import type { MenuProps } from "antd";
import { appRouteMeta } from "./route-config";

export function buildMenuItems(role: Role | undefined): MenuProps["items"] {
  return appRouteMeta
    .filter((route) => route.showInMenu)
    .filter((route) => !route.roles || (role ? route.roles.includes(role) : false))
    .map((route) => ({
      key: route.path,
      label: route.title,
      icon: route.icon
    }));
}

export function getRouteTitle(pathname: string): string {
  const found = appRouteMeta.find((route) => pathname.startsWith(route.path));
  return found?.title ?? "Страница";
}
