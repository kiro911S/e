import { jsx as _jsx } from "react/jsx-runtime";
import { AuditOutlined, BookOutlined, DashboardOutlined, FileTextOutlined, ProfileOutlined, ReadOutlined, TeamOutlined } from "@ant-design/icons";
import { Role } from "@ot/shared";
export const appRouteMeta = [
    {
        key: "dashboard",
        path: "/dashboard",
        title: "Дашборд",
        icon: _jsx(DashboardOutlined, {}),
        showInMenu: true
    },
    {
        key: "programs",
        path: "/programs",
        title: "Программы",
        icon: _jsx(BookOutlined, {}),
        showInMenu: true
    },
    {
        key: "briefings",
        path: "/briefings",
        title: "Журналы",
        icon: _jsx(ReadOutlined, {}),
        roles: [Role.Admin, Role.Inspector],
        showInMenu: true
    },
    {
        key: "tests",
        path: "/tests",
        title: "Тестирование",
        icon: _jsx(AuditOutlined, {}),
        showInMenu: true
    },
    {
        key: "reports",
        path: "/reports",
        title: "Отчёты",
        icon: _jsx(FileTextOutlined, {}),
        roles: [Role.Admin, Role.Inspector],
        showInMenu: true
    },
    {
        key: "profile",
        path: "/profile",
        title: "Профиль",
        icon: _jsx(ProfileOutlined, {}),
        showInMenu: true
    },
    {
        key: "adminUsers",
        path: "/admin/users",
        title: "Пользователи",
        icon: _jsx(TeamOutlined, {}),
        roles: [Role.Admin],
        showInMenu: true
    },
    {
        key: "adminDirectories",
        path: "/admin/directories",
        title: "Справочники",
        icon: _jsx(BookOutlined, {}),
        roles: [Role.Admin],
        showInMenu: true
    }
];
