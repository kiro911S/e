import { Role } from "@ot/shared";

export type PolicyAction =
  | "users:read"
  | "users:write"
  | "directories:write"
  | "programs:write"
  | "journals:write"
  | "tests:submit"
  | "reports:read";

const policyMap: Record<Role, PolicyAction[]> = {
  [Role.Admin]: [
    "users:read",
    "users:write",
    "directories:write",
    "programs:write",
    "journals:write",
    "reports:read"
  ],
  [Role.Inspector]: [
    "users:read",
    "journals:write",
    "reports:read"
  ],
  [Role.Employee]: ["tests:submit"],
  [Role.Guest]: []
};

export function can(role: Role | undefined, action: PolicyAction): boolean {
  if (!role) {
    return false;
  }
  return policyMap[role].includes(action);
}
