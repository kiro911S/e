import { Role } from "@ot/shared";
const policyMap = {
    [Role.Admin]: [
        "users:read",
        "users:write",
        "directories:write",
        "programs:write",
        "journals:write",
        "reports:read"
    ],
    [Role.Inspector]: [
        "users:read",
        "journals:write",
        "reports:read"
    ],
    [Role.Employee]: ["tests:submit"],
    [Role.Guest]: []
};
export function can(role, action) {
    if (!role) {
        return false;
    }
    return policyMap[role].includes(action);
}
