import { useMemo } from "react";
import { can, type PolicyAction } from "./policy-map";
import { useAuthStore } from "../../store/auth-store";

export function useCan(action: PolicyAction): boolean {
  const role = useAuthStore((state) => state.user?.role);
  return useMemo(() => can(role, action), [role, action]);
}
