import { jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
import { Spin } from "antd";
import { useEffect } from "react";
import { authApi } from "../../api/auth-api";
import { useAuthStore } from "../../store/auth-store";
export function AuthBootstrap({ children }) {
    const setAuth = useAuthStore((state) => state.setAuth);
    const finishBootstrap = useAuthStore((state) => state.finishBootstrap);
    const isBootstrapping = useAuthStore((state) => state.isBootstrapping);
    useEffect(() => {
        void authApi
            .refresh()
            .then((data) => {
            setAuth({ token: data.accessToken, user: data.user });
        })
            .catch(() => {
            finishBootstrap();
        });
    }, [finishBootstrap, setAuth]);
    if (isBootstrapping) {
        return (_jsx("main", { style: { minHeight: "100vh", display: "grid", placeItems: "center" }, children: _jsx(Spin, { size: "large" }) }));
    }
    return _jsx(_Fragment, { children: children });
}
