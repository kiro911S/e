import { jsx as _jsx } from "react/jsx-runtime";
import { App, ConfigProvider, theme } from "antd";
import ruRU from "antd/locale/ru_RU";
import { createContext, useContext, useMemo, useState } from "react";
import { darkThemeTokens, lightThemeTokens } from "../theme/tokens";
const ThemeModeContext = createContext(null);
export function AntdProvider({ children }) {
    const [isDarkMode, setIsDarkMode] = useState(false);
    const contextValue = useMemo(() => ({
        isDarkMode,
        toggleThemeMode: () => {
            setIsDarkMode((prev) => !prev);
        }
    }), [isDarkMode]);
    return (_jsx(ThemeModeContext.Provider, { value: contextValue, children: _jsx(ConfigProvider, { locale: ruRU, theme: {
                ...(isDarkMode ? darkThemeTokens : lightThemeTokens),
                algorithm: isDarkMode ? theme.darkAlgorithm : theme.defaultAlgorithm
            }, children: _jsx(App, { children: children }) }) }));
}
export function useThemeMode() {
    const context = useContext(ThemeModeContext);
    if (!context) {
        throw new Error("useThemeMode must be used within AntdProvider");
    }
    return context;
}
