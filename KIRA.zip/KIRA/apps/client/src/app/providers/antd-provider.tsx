import { App, ConfigProvider, theme } from "antd";
import ruRU from "antd/locale/ru_RU";
import { createContext, type ReactNode, useContext, useMemo, useState } from "react";
import { darkThemeTokens, lightThemeTokens } from "../theme/tokens";

interface ThemeModeContextValue {
  isDarkMode: boolean;
  toggleThemeMode: () => void;
}

const ThemeModeContext = createContext<ThemeModeContextValue | null>(null);

interface AntdProviderProps {
  children: ReactNode;
}

export function AntdProvider({ children }: AntdProviderProps) {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const contextValue = useMemo<ThemeModeContextValue>(
    () => ({
      isDarkMode,
      toggleThemeMode: () => {
        setIsDarkMode((prev) => !prev);
      }
    }),
    [isDarkMode]
  );

  return (
    <ThemeModeContext.Provider value={contextValue}>
      <ConfigProvider
        locale={ruRU}
        theme={{
          ...(isDarkMode ? darkThemeTokens : lightThemeTokens),
          algorithm: isDarkMode ? theme.darkAlgorithm : theme.defaultAlgorithm
        }}
      >
        <App>{children}</App>
      </ConfigProvider>
    </ThemeModeContext.Provider>
  );
}

export function useThemeMode(): ThemeModeContextValue {
  const context = useContext(ThemeModeContext);
  if (!context) {
    throw new Error("useThemeMode must be used within AntdProvider");
  }
  return context;
}
