import { Spin } from "antd";
import { type ReactNode, useEffect } from "react";
import { authApi } from "../../api/auth-api";
import { useAuthStore } from "../../store/auth-store";

interface AuthBootstrapProps {
  children: ReactNode;
}

export function AuthBootstrap({ children }: AuthBootstrapProps) {
  const setAuth = useAuthStore((state) => state.setAuth);
  const finishBootstrap = useAuthStore((state) => state.finishBootstrap);
  const isBootstrapping = useAuthStore((state) => state.isBootstrapping);

  useEffect(() => {
    void authApi
      .refresh()
      .then((data) => {
        setAuth({ token: data.accessToken, user: data.user });
      })
      .catch(() => {
        finishBootstrap();
      });
  }, [finishBootstrap, setAuth]);

  if (isBootstrapping) {
    return (
      <main style={{ minHeight: "100vh", display: "grid", placeItems: "center" }}>
        <Spin size="large" />
      </main>
    );
  }

  return <>{children}</>;
}
