import type { ThemeConfig } from "antd";

export const lightThemeTokens: ThemeConfig = {
  token: {
    borderRadius: 10,
    colorPrimary: "#1677ff",
    colorInfo: "#1677ff",
    fontSize: 14
  },
  components: {
    Layout: {
      headerBg: "#ffffff",
      bodyBg: "#f5f7fb",
      siderBg: "#001529",
      triggerBg: "#001529"
    }
  }
};

export const darkThemeTokens: ThemeConfig = {
  token: {
    borderRadius: 10,
    colorPrimary: "#4096ff",
    colorInfo: "#4096ff",
    fontSize: 14,
    colorBgLayout: "#141414",
    colorBgContainer: "#1f1f1f"
  },
  components: {
    Layout: {
      headerBg: "#141414",
      bodyBg: "#0f1115",
      siderBg: "#111827",
      triggerBg: "#111827"
    }
  }
};
