import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { RouterProvider } from "react-router-dom";
import "antd/dist/reset.css";
import { AntdProvider } from "./app/providers/antd-provider";
import { AuthBootstrap } from "./app/providers/auth-bootstrap";
import { router } from "./router";

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <AntdProvider>
      <AuthBootstrap>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
        </QueryClientProvider>
      </AuthBootstrap>
    </AntdProvider>
  </React.StrictMode>
);
