import { api } from "./client";
export const testsApi = {
    getResults: async () => {
        const response = await api.get("/test/results");
        return response.data;
    },
    submit: async (payload) => {
        const response = await api.post("/test/submit", payload);
        return response.data;
    }
};
