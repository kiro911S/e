import { api } from "./client";

export interface DirectoryItem {
  id: string;
  name: string;
  code?: string;
  periodicityMonths?: number;
}

export interface CreateDepartmentPayload {
  name: string;
  code: string;
}

export interface CreatePositionPayload {
  name: string;
}

export interface CreateBriefingTypePayload {
  name: string;
  periodicityMonths: number;
}

export const directoriesApi = {
  getDepartments: async (): Promise<DirectoryItem[]> => {
    const response = await api.get<DirectoryItem[]>("/departments");
    return response.data;
  },
  getPositions: async (): Promise<DirectoryItem[]> => {
    const response = await api.get<DirectoryItem[]>("/positions");
    return response.data;
  },
  getBriefingTypes: async (): Promise<DirectoryItem[]> => {
    const response = await api.get<DirectoryItem[]>("/briefing-types");
    return response.data;
  },
  createDepartment: async (payload: CreateDepartmentPayload): Promise<DirectoryItem> => {
    const response = await api.post<DirectoryItem>("/departments", payload);
    return response.data;
  },
  createPosition: async (payload: CreatePositionPayload): Promise<DirectoryItem> => {
    const response = await api.post<DirectoryItem>("/positions", payload);
    return response.data;
  },
  createBriefingType: async (payload: CreateBriefingTypePayload): Promise<DirectoryItem> => {
    const response = await api.post<DirectoryItem>("/briefing-types", payload);
    return response.data;
  },
  updateDepartment: async (id: string, payload: Partial<CreateDepartmentPayload>): Promise<DirectoryItem> => {
    const response = await api.patch<DirectoryItem>(`/departments/${id}`, payload);
    return response.data;
  },
  updatePosition: async (id: string, payload: Partial<CreatePositionPayload>): Promise<DirectoryItem> => {
    const response = await api.patch<DirectoryItem>(`/positions/${id}`, payload);
    return response.data;
  },
  updateBriefingType: async (id: string, payload: Partial<CreateBriefingTypePayload>): Promise<DirectoryItem> => {
    const response = await api.patch<DirectoryItem>(`/briefing-types/${id}`, payload);
    return response.data;
  },
  removeDepartment: async (id: string): Promise<{ success: boolean }> => {
    const response = await api.delete<{ success: boolean }>(`/departments/${id}`);
    return response.data;
  },
  removePosition: async (id: string): Promise<{ success: boolean }> => {
    const response = await api.delete<{ success: boolean }>(`/positions/${id}`);
    return response.data;
  },
  removeBriefingType: async (id: string): Promise<{ success: boolean }> => {
    const response = await api.delete<{ success: boolean }>(`/briefing-types/${id}`);
    return response.data;
  }
};
