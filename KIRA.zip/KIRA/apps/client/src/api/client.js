import axios from "axios";
import { useAuthStore } from "../store/auth-store";
export const api = axios.create({
    baseURL: "http://localhost:3001/api/v1",
    withCredentials: true
});
api.interceptors.request.use((config) => {
    const token = useAuthStore.getState().token;
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});
api.interceptors.response.use((response) => response, (error) => {
    if (axios.isAxiosError(error) &&
        error.response?.status === 401 &&
        error.config) {
        const originalRequest = error.config;
        if (originalRequest.url?.includes("/auth/refresh")) {
            useAuthStore.getState().logout();
            window.location.href = "/login";
            return Promise.reject(error);
        }
        if (!originalRequest._retry) {
            originalRequest._retry = true;
            return axios
                .post(`${api.defaults.baseURL}/auth/refresh`, undefined, {
                withCredentials: true
            })
                .then((data) => {
                useAuthStore.getState().setAuth({
                    token: data.data.accessToken,
                    user: data.data.user
                });
                originalRequest.headers.Authorization = `Bearer ${data.data.accessToken}`;
                return api(originalRequest);
            })
                .catch((refreshError) => {
                useAuthStore.getState().logout();
                window.location.href = "/login";
                return Promise.reject(refreshError);
            });
        }
        useAuthStore.getState().logout();
        window.location.href = "/login";
    }
    return Promise.reject(error);
});
