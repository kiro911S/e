import { api } from "./client";
export const programsApi = {
    getAll: async () => {
        const response = await api.get("/programs");
        return response.data;
    },
    create: async (payload) => {
        const response = await api.post("/programs", payload);
        return response.data;
    },
    update: async (id, payload) => {
        const response = await api.patch(`/programs/${id}`, payload);
        return response.data;
    },
    remove: async (id) => {
        const response = await api.delete(`/programs/${id}`);
        return response.data;
    },
    uploadPdf: async (id, file) => {
        const formData = new FormData();
        formData.append("file", file);
        const response = await api.post(`/programs/${id}/upload-pdf`, formData, {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });
        return response.data;
    }
};
