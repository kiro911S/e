import { api } from "./client";
export const directoriesApi = {
    getDepartments: async () => {
        const response = await api.get("/departments");
        return response.data;
    },
    getPositions: async () => {
        const response = await api.get("/positions");
        return response.data;
    },
    getBriefingTypes: async () => {
        const response = await api.get("/briefing-types");
        return response.data;
    },
    createDepartment: async (payload) => {
        const response = await api.post("/departments", payload);
        return response.data;
    },
    createPosition: async (payload) => {
        const response = await api.post("/positions", payload);
        return response.data;
    },
    createBriefingType: async (payload) => {
        const response = await api.post("/briefing-types", payload);
        return response.data;
    },
    updateDepartment: async (id, payload) => {
        const response = await api.patch(`/departments/${id}`, payload);
        return response.data;
    },
    updatePosition: async (id, payload) => {
        const response = await api.patch(`/positions/${id}`, payload);
        return response.data;
    },
    updateBriefingType: async (id, payload) => {
        const response = await api.patch(`/briefing-types/${id}`, payload);
        return response.data;
    },
    removeDepartment: async (id) => {
        const response = await api.delete(`/departments/${id}`);
        return response.data;
    },
    removePosition: async (id) => {
        const response = await api.delete(`/positions/${id}`);
        return response.data;
    },
    removeBriefingType: async (id) => {
        const response = await api.delete(`/briefing-types/${id}`);
        return response.data;
    }
};
