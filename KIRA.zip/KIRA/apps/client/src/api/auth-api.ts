import { LoginDto, Role } from "@ot/shared";
import { api } from "./client";

interface LoginResponse {
  accessToken: string;
  user: {
    id: string;
    fullName: string;
    email: string;
    role: Role;
  };
}

export const authApi = {
  login: async (payload: LoginDto): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>("/auth/login", payload);
    return response.data;
  },
  refresh: async (): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>("/auth/refresh");
    return response.data;
  },
  me: async (): Promise<LoginResponse["user"]> => {
    const response = await api.get<LoginResponse["user"]>("/auth/me");
    return response.data;
  },
  logout: async (): Promise<void> => {
    await api.post("/auth/logout");
  }
};
