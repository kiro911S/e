import { api } from "./client";

export interface TestResultItem {
  id: string;
  score: number;
  status: string;
  journalId?: string;
  employeeId?: string;
}

export interface SubmitTestPayload {
  journalId: string;
  answers: Array<{ questionId: string; answer: string }>;
}

export const testsApi = {
  getResults: async (): Promise<TestResultItem[]> => {
    const response = await api.get<TestResultItem[]>("/test/results");
    return response.data;
  },
  submit: async (payload: SubmitTestPayload): Promise<TestResultItem> => {
    const response = await api.post<TestResultItem>("/test/submit", payload);
    return response.data;
  }
};
