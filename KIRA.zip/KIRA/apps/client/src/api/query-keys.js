export const appKeys = {
    users: {
        all: ["users"]
    },
    directories: {
        departments: ["directories", "departments"],
        positions: ["directories", "positions"],
        briefingTypes: ["directories", "briefing-types"]
    },
    programs: {
        all: ["programs"]
    },
    journals: {
        all: ["journals"]
    },
    tests: {
        results: ["tests", "results"]
    },
    reports: {
        completion: (from, to) => ["reports", "completion", from, to]
    }
};
