export const appKeys = {
  users: {
    all: ["users"] as const
  },
  directories: {
    departments: ["directories", "departments"] as const,
    positions: ["directories", "positions"] as const,
    briefingTypes: ["directories", "briefing-types"] as const
  },
  programs: {
    all: ["programs"] as const
  },
  journals: {
    all: ["journals"] as const
  },
  tests: {
    results: ["tests", "results"] as const
  },
  reports: {
    completion: (from: string, to: string) => ["reports", "completion", from, to] as const
  }
};
