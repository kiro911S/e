import { api } from "./client";

export interface CompletionReportItem {
  departmentName: string;
  totalEmployees: number;
  completed: number;
  failed: number;
}

export interface ReportsSummary {
  users: number;
  journals: number;
  programs: number;
  tests: number;
}

export interface JournalReportItem {
  id: string;
  briefingDate: string;
  status: string;
  program: {
    title: string;
  };
  department: {
    name: string;
  };
}

export interface EmployeeHistoryRecord {
  id: string;
  signedAt?: string;
  journal: {
    briefingDate: string;
    program: {
      title: string;
    };
  };
}

export interface EmployeeHistoryResponse {
  records: EmployeeHistoryRecord[];
  testResults: Array<{
    id: string;
    score: number;
    status: string;
  }>;
}

export const reportsApi = {
  getCompletion: async (from: string, to: string): Promise<CompletionReportItem[]> => {
    const response = await api.get<CompletionReportItem[]>("/reports/completion", {
      params: { from, to }
    });
    return response.data;
  },
  getSummary: async (): Promise<ReportsSummary> => {
    const response = await api.get<ReportsSummary>("/reports/summary");
    return response.data;
  },
  getUpcoming: async (days = 14): Promise<JournalReportItem[]> => {
    const response = await api.get<JournalReportItem[]>("/reports/upcoming", {
      params: { days }
    });
    return response.data;
  },
  getOverdue: async (): Promise<JournalReportItem[]> => {
    const response = await api.get<JournalReportItem[]>("/reports/overdue");
    return response.data;
  },
  getEmployeeHistory: async (employeeId: string): Promise<EmployeeHistoryResponse> => {
    const response = await api.get<EmployeeHistoryResponse>("/reports/employee-history", {
      params: { employeeId }
    });
    return response.data;
  },
  exportCompletionCsv: (rows: CompletionReportItem[]): Blob => {
    const header = "Подразделение;Всего;Пройдено;Не пройдено";
    const lines = rows.map((row) => `${row.departmentName};${row.totalEmployees};${row.completed};${row.failed}`);
    const content = [header, ...lines].join("\n");
    return new Blob([content], { type: "text/csv;charset=utf-8;" });
  }
};
