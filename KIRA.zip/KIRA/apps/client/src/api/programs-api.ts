import { ProgramStatus } from "@ot/shared";
import { api } from "./client";

export interface ProgramQuestionItem {
  id: string;
  text: string;
  order: number;
  isRequired: boolean;
}

export interface ProgramItem {
  id: string;
  title: string;
  status: ProgramStatus;
  description?: string;
  briefingTypeId?: string;
  questions?: ProgramQuestionItem[];
  documentUrl?: string | null;
}

export interface CreateProgramPayload {
  title: string;
  description?: string;
  briefingTypeId: string;
  status: ProgramStatus;
  questions: Array<{ text: string; order: number; isRequired: boolean }>;
}

export const programsApi = {
  getAll: async (): Promise<ProgramItem[]> => {
    const response = await api.get<ProgramItem[]>("/programs");
    return response.data;
  },
  create: async (payload: CreateProgramPayload): Promise<ProgramItem> => {
    const response = await api.post<ProgramItem>("/programs", payload);
    return response.data;
  },
  update: async (id: string, payload: Partial<CreateProgramPayload>): Promise<ProgramItem> => {
    const response = await api.patch<ProgramItem>(`/programs/${id}`, payload);
    return response.data;
  },
  remove: async (id: string): Promise<{ success: boolean }> => {
    const response = await api.delete<{ success: boolean }>(`/programs/${id}`);
    return response.data;
  },
  uploadPdf: async (id: string, file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    const response = await api.post(`/programs/${id}/upload-pdf`, formData, {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    });
    return response.data;
  }
};
