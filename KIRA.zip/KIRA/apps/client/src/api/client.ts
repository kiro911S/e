import axios from "axios";
import { Role } from "@ot/shared";
import { useAuthStore } from "../store/auth-store";

export const api = axios.create({
  baseURL: "http://localhost:3001/api/v1",
  withCredentials: true
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error: unknown) => {
    if (
      axios.isAxiosError(error) &&
      error.response?.status === 401 &&
      error.config
    ) {
      const originalRequest = error.config as typeof error.config & {
        _retry?: boolean;
      };
      if (originalRequest.url?.includes("/auth/refresh")) {
        useAuthStore.getState().logout();
        return Promise.reject(error);
      }

      if (!originalRequest._retry) {
        originalRequest._retry = true;
        return axios
          .post<{
            accessToken: string;
            user: {
              id: string;
              fullName: string;
              email: string;
                role: Role;
            };
          }>(`${api.defaults.baseURL}/auth/refresh`, undefined, {
            withCredentials: true
          })
          .then((data) => {
            useAuthStore.getState().setAuth({
              token: data.data.accessToken,
              user: data.data.user
            });
            originalRequest.headers.Authorization = `Bearer ${data.data.accessToken}`;
            return api(originalRequest);
          })
          .catch((refreshError: unknown) => {
            useAuthStore.getState().logout();
            return Promise.reject(refreshError);
          });
      }

      useAuthStore.getState().logout();
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);
