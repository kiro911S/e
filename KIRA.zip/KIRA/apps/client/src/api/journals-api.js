import { api } from "./client";
export const journalsApi = {
    getAll: async () => {
        const response = await api.get("/journals");
        return response.data;
    },
    create: async (payload) => {
        const response = await api.post("/journals", payload);
        return response.data;
    },
    update: async (id, payload) => {
        const response = await api.patch(`/journals/${id}`, payload);
        return response.data;
    },
    getMyBriefings: async () => {
        const response = await api.get("/journals/me/briefings");
        return response.data;
    }
};
