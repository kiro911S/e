import { api } from "./client";
export const usersApi = {
    getAll: async () => {
        const response = await api.get("/users");
        return response.data;
    },
    create: async (payload) => {
        const response = await api.post("/users", payload);
        return response.data;
    },
    update: async (id, payload) => {
        const response = await api.patch(`/users/${id}`, payload);
        return response.data;
    },
    toggleStatus: async (id, isActive) => {
        const response = await api.patch(`/users/${id}/status`, undefined, {
            params: { isActive }
        });
        return response.data;
    },
    resetPassword: async (id, password) => {
        const response = await api.post(`/users/${id}/reset-password`, {
            password
        });
        return response.data;
    },
    remove: async (id) => {
        const response = await api.delete(`/users/${id}`);
        return response.data;
    }
};
