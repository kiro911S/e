import { JournalStatus } from "@ot/shared";
import { api } from "./client";

export interface JournalItem {
  id: string;
  briefingDate: string;
  status: JournalStatus;
  programId?: string;
  instructorId?: string;
  departmentId?: string;
}

export interface CreateJournalPayload {
  programId: string;
  briefingDate: string;
  instructorId: string;
  departmentId: string;
  status: JournalStatus;
}

export const journalsApi = {
  getAll: async (): Promise<JournalItem[]> => {
    const response = await api.get<JournalItem[]>("/journals");
    return response.data;
  },
  create: async (payload: CreateJournalPayload): Promise<JournalItem> => {
    const response = await api.post<JournalItem>("/journals", payload);
    return response.data;
  },
  update: async (id: string, payload: Partial<CreateJournalPayload>): Promise<JournalItem> => {
    const response = await api.patch<JournalItem>(`/journals/${id}`, payload);
    return response.data;
  },
  getMyBriefings: async () => {
    const response = await api.get("/journals/me/briefings");
    return response.data;
  }
};
