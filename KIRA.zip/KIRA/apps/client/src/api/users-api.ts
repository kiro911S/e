import { Role, UserStatus } from "@ot/shared";
import { api } from "./client";

export interface UserItem {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  departmentId: string;
  positionId: string;
  hireDate: string;
  status: UserStatus;
}

export interface CreateUserPayload {
  fullName: string;
  email: string;
  role: Role;
  departmentId: string;
  positionId: string;
  hireDate: string;
  status: UserStatus;
}

export const usersApi = {
  getAll: async (): Promise<UserItem[]> => {
    const response = await api.get<UserItem[]>("/users");
    return response.data;
  },
  create: async (payload: CreateUserPayload): Promise<UserItem> => {
    const response = await api.post<UserItem>("/users", payload);
    return response.data;
  },
  update: async (id: string, payload: Partial<CreateUserPayload>): Promise<UserItem> => {
    const response = await api.patch<UserItem>(`/users/${id}`, payload);
    return response.data;
  },
  toggleStatus: async (id: string, isActive: boolean): Promise<UserItem> => {
    const response = await api.patch<UserItem>(`/users/${id}/status`, undefined, {
      params: { isActive }
    });
    return response.data;
  },
  resetPassword: async (id: string, password?: string): Promise<{ temporaryPassword: string }> => {
    const response = await api.post<{ temporaryPassword: string }>(`/users/${id}/reset-password`, {
      password
    });
    return response.data;
  },
  remove: async (id: string): Promise<{ success: boolean }> => {
    const response = await api.delete<{ success: boolean }>(`/users/${id}`);
    return response.data;
  }
};
