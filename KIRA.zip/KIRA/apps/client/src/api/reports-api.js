import { api } from "./client";
export const reportsApi = {
    getCompletion: async (from, to) => {
        const response = await api.get("/reports/completion", {
            params: { from, to }
        });
        return response.data;
    },
    getSummary: async () => {
        const response = await api.get("/reports/summary");
        return response.data;
    },
    getUpcoming: async (days = 14) => {
        const response = await api.get("/reports/upcoming", {
            params: { days }
        });
        return response.data;
    },
    getOverdue: async () => {
        const response = await api.get("/reports/overdue");
        return response.data;
    },
    getEmployeeHistory: async (employeeId) => {
        const response = await api.get("/reports/employee-history", {
            params: { employeeId }
        });
        return response.data;
    },
    exportCompletionCsv: (rows) => {
        const header = "Подразделение;Всего;Пройдено;Не пройдено";
        const lines = rows.map((row) => `${row.departmentName};${row.totalEmployees};${row.completed};${row.failed}`);
        const content = [header, ...lines].join("\n");
        return new Blob([content], { type: "text/csv;charset=utf-8;" });
    }
};
