import { Role } from "@ot/shared";
import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "../store/auth-store";

interface PrivateRouteProps {
  roles?: Role[];
}

export function PrivateRoute({ roles }: PrivateRouteProps) {
  const { isAuthenticated, user } = useAuthStore();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (roles && (!user?.role || !roles.includes(user.role))) {
    return <Navigate to="/forbidden" replace />;
  }

  return <Outlet />;
}
