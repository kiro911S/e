import { jsx as _jsx } from "react/jsx-runtime";
import { Modal } from "antd";
export function EntityFormModal({ title, open, onCancel, onSubmit, submitLabel = "Сохранить", confirmLoading = false, children }) {
    return (_jsx(Modal, { title: title, open: open, onCancel: onCancel, onOk: onSubmit, okText: submitLabel, cancelText: "\u041E\u0442\u043C\u0435\u043D\u0430", confirmLoading: confirmLoading, destroyOnClose: true, children: children }));
}
