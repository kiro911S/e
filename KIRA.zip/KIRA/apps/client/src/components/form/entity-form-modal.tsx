import { Modal } from "antd";
import type { ReactNode } from "react";

interface EntityFormModalProps {
  title: string;
  open: boolean;
  onCancel: () => void;
  onSubmit: () => void;
  submitLabel?: string;
  confirmLoading?: boolean;
  children: ReactNode;
}

export function EntityFormModal({
  title,
  open,
  onCancel,
  onSubmit,
  submitLabel = "Сохранить",
  confirmLoading = false,
  children
}: EntityFormModalProps) {
  return (
    <Modal
      title={title}
      open={open}
      onCancel={onCancel}
      onOk={onSubmit}
      okText={submitLabel}
      cancelText="Отмена"
      confirmLoading={confirmLoading}
      destroyOnClose
    >
      {children}
    </Modal>
  );
}
