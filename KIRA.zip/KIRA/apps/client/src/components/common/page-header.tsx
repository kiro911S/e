import { Button, Flex, Typography } from "antd";
import type { ReactNode } from "react";

interface PageHeaderProps {
  title: string;
  description?: string;
  actionText?: string;
  onActionClick?: () => void;
  extra?: ReactNode;
}

export function PageHeader({ title, description, actionText, onActionClick, extra }: PageHeaderProps) {
  return (
    <Flex align="center" justify="space-between" gap={16} wrap>
      <div>
        <Typography.Title level={3} style={{ marginBottom: 4 }}>
          {title}
        </Typography.Title>
        {description ? (
          <Typography.Text type="secondary">
            {description}
          </Typography.Text>
        ) : null}
      </div>
      <Flex gap={8} wrap>
        {extra}
        {actionText && onActionClick ? (
          <Button type="primary" onClick={onActionClick}>
            {actionText}
          </Button>
        ) : null}
      </Flex>
    </Flex>
  );
}
