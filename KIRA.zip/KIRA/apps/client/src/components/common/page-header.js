import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Flex, Typography } from "antd";
export function PageHeader({ title, description, actionText, onActionClick, extra }) {
    return (_jsxs(Flex, { align: "center", justify: "space-between", gap: 16, wrap: true, children: [_jsxs("div", { children: [_jsx(Typography.Title, { level: 3, style: { marginBottom: 4 }, children: title }), description ? (_jsx(Typography.Text, { type: "secondary", children: description })) : null] }), _jsxs(Flex, { gap: 8, wrap: true, children: [extra, actionText && onActionClick ? (_jsx(Button, { type: "primary", onClick: onActionClick, children: actionText })) : null] })] }));
}
