import { Result, Skeleton, Space } from "antd";
import type { ReactNode } from "react";

interface PageStateProps {
  isLoading: boolean;
  isError: boolean;
  errorTitle?: string;
  children: ReactNode;
}

export function PageState({
  isLoading,
  isError,
  errorTitle = "Не удалось загрузить данные",
  children
}: PageStateProps) {
  if (isLoading) {
    return (
      <Space direction="vertical" size={16} style={{ width: "100%" }}>
        <Skeleton active paragraph={{ rows: 3 }} />
        <Skeleton active paragraph={{ rows: 4 }} />
      </Space>
    );
  }

  if (isError) {
    return <Result status="error" title={errorTitle} />;
  }

  return <>{children}</>;
}
