import { jsx as _jsx } from "react/jsx-runtime";
import { Empty } from "antd";
export function EmptyState({ description }) {
    return _jsx(Empty, { description: description, image: Empty.PRESENTED_IMAGE_SIMPLE });
}
