import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Result, Skeleton, Space } from "antd";
export function PageState({ isLoading, isError, errorTitle = "Не удалось загрузить данные", children }) {
    if (isLoading) {
        return (_jsxs(Space, { direction: "vertical", size: 16, style: { width: "100%" }, children: [_jsx(Skeleton, { active: true, paragraph: { rows: 3 } }), _jsx(Skeleton, { active: true, paragraph: { rows: 4 } })] }));
    }
    if (isError) {
        return _jsx(Result, { status: "error", title: errorTitle });
    }
    return _jsx(_Fragment, { children: children });
}
