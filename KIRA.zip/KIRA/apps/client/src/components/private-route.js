import { jsx as _jsx } from "react/jsx-runtime";
import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "../store/auth-store";
export function PrivateRoute({ roles }) {
    const { isAuthenticated, user } = useAuthStore();
    if (!isAuthenticated) {
        return _jsx(Navigate, { to: "/login", replace: true });
    }
    if (roles && (!user?.role || !roles.includes(user.role))) {
        return _jsx(Navigate, { to: "/forbidden", replace: true });
    }
    return _jsx(Outlet, {});
}
