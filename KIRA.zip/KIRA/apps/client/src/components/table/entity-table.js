import { jsx as _jsx } from "react/jsx-runtime";
import { Table } from "antd";
export function EntityTable({ data, columns }) {
    return (_jsx(Table, { rowKey: "id", columns: columns, dataSource: data, pagination: { pageSize: 10, showSizeChanger: false } }));
}
