import { Table } from "antd";
import type { TableColumnsType } from "antd";

interface EntityTableProps<T extends { id: string }> {
  data: T[];
  columns: TableColumnsType<T>;
}

export function EntityTable<T extends { id: string }>({ data, columns }: EntityTableProps<T>) {
  return (
    <Table<T>
      rowKey="id"
      columns={columns}
      dataSource={data}
      pagination={{ pageSize: 10, showSizeChanger: false }}
    />
  );
}
