import { Role } from "@ot/shared";
import { createBrowserRouter } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { PrivateRoute } from "./components/private-route";
import { BriefingsPage } from "./pages/briefings-page";
import { DashboardPage } from "./pages/dashboard-page";
import { DirectoriesPage } from "./pages/directories-page";
import { ForbiddenPage } from "./pages/forbidden-page";
import { LoginPage } from "./pages/login-page";
import { NotFoundPage } from "./pages/not-found-page";
import { PageShell } from "./pages/page-shell";
import { ProfilePage } from "./pages/profile-page";
import { ProgramsPage } from "./pages/programs-page";
import { ReportsPage } from "./pages/reports-page";
import { TestsPage } from "./pages/tests-page";
import { UsersPage } from "./pages/users-page";

export const router = createBrowserRouter([
  { path: "/", element: <Navigate to="/dashboard" replace /> },
  { path: "/login", element: <LoginPage /> },
  { path: "/forbidden", element: <ForbiddenPage /> },
  {
    element: <PrivateRoute />,
    children: [
      {
        element: <PageShell />,
        children: [
          { path: "/dashboard", element: <DashboardPage /> },
          { path: "/programs", element: <ProgramsPage /> },
          { path: "/programs/new", element: <ProgramsPage /> },
          { path: "/programs/:id/edit", element: <ProgramsPage /> },
          { path: "/tests", element: <TestsPage /> },
          { path: "/profile", element: <ProfilePage /> }
        ]
      }
    ]
  },
  {
    element: <PrivateRoute roles={[Role.Admin, Role.Inspector]} />,
    children: [
      {
        element: <PageShell />,
        children: [
          { path: "/briefings", element: <BriefingsPage /> },
          { path: "/briefings/journals", element: <BriefingsPage /> },
          { path: "/briefings/new", element: <BriefingsPage /> },
          { path: "/briefings/:id", element: <BriefingsPage /> },
          { path: "/briefings/:id/test", element: <TestsPage /> },
          { path: "/reports", element: <ReportsPage /> },
          { path: "/reports/overdue", element: <ReportsPage /> }
        ]
      }
    ]
  },
  {
    element: <PrivateRoute roles={[Role.Admin]} />,
    children: [
      {
        element: <PageShell />,
        children: [
          { path: "/admin/users", element: <UsersPage /> },
          { path: "/admin/users/:id", element: <UsersPage /> },
          { path: "/admin/directories", element: <DirectoriesPage /> }
        ]
      }
    ]
  },
  { path: "*", element: <NotFoundPage /> }
]);
