import { jsx as _jsx } from "react/jsx-runtime";
import { Role } from "@ot/shared";
import { createBrowserRouter } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { PrivateRoute } from "./components/private-route";
import { BriefingsPage } from "./pages/briefings-page";
import { DashboardPage } from "./pages/dashboard-page";
import { DirectoriesPage } from "./pages/directories-page";
import { ForbiddenPage } from "./pages/forbidden-page";
import { LoginPage } from "./pages/login-page";
import { NotFoundPage } from "./pages/not-found-page";
import { PageShell } from "./pages/page-shell";
import { ProfilePage } from "./pages/profile-page";
import { ProgramsPage } from "./pages/programs-page";
import { ReportsPage } from "./pages/reports-page";
import { TestsPage } from "./pages/tests-page";
import { UsersPage } from "./pages/users-page";
export const router = createBrowserRouter([
    { path: "/", element: _jsx(Navigate, { to: "/dashboard", replace: true }) },
    { path: "/login", element: _jsx(LoginPage, {}) },
    { path: "/forbidden", element: _jsx(ForbiddenPage, {}) },
    {
        element: _jsx(PrivateRoute, {}),
        children: [
            {
                element: _jsx(PageShell, {}),
                children: [
                    { path: "/dashboard", element: _jsx(DashboardPage, {}) },
                    { path: "/programs", element: _jsx(ProgramsPage, {}) },
                    { path: "/programs/new", element: _jsx(ProgramsPage, {}) },
                    { path: "/programs/:id/edit", element: _jsx(ProgramsPage, {}) },
                    { path: "/tests", element: _jsx(TestsPage, {}) },
                    { path: "/profile", element: _jsx(ProfilePage, {}) }
                ]
            }
        ]
    },
    {
        element: _jsx(PrivateRoute, { roles: [Role.Admin, Role.Inspector] }),
        children: [
            {
                element: _jsx(PageShell, {}),
                children: [
                    { path: "/briefings", element: _jsx(BriefingsPage, {}) },
                    { path: "/briefings/journals", element: _jsx(BriefingsPage, {}) },
                    { path: "/briefings/new", element: _jsx(BriefingsPage, {}) },
                    { path: "/briefings/:id", element: _jsx(BriefingsPage, {}) },
                    { path: "/briefings/:id/test", element: _jsx(TestsPage, {}) },
                    { path: "/reports", element: _jsx(ReportsPage, {}) },
                    { path: "/reports/overdue", element: _jsx(ReportsPage, {}) }
                ]
            }
        ]
    },
    {
        element: _jsx(PrivateRoute, { roles: [Role.Admin] }),
        children: [
            {
                element: _jsx(PageShell, {}),
                children: [
                    { path: "/admin/users", element: _jsx(UsersPage, {}) },
                    { path: "/admin/users/:id", element: _jsx(UsersPage, {}) },
                    { path: "/admin/directories", element: _jsx(DirectoriesPage, {}) }
                ]
            }
        ]
    },
    { path: "*", element: _jsx(NotFoundPage, {}) }
]);
