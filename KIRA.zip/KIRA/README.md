# KIRA — учет инструктажей по ОТ

MVP-скелет pnpm-монорепо:

- `apps/client` — React + Vite + TypeScript
- `apps/server` — NestJS + Prisma
- `packages/shared` — общие Zod-схемы и TypeScript-типы

## Быстрый старт

1. Скопируйте переменные окружения:
   - `cp .env.example .env` (или вручную в Windows)
2. Установите зависимости:
   - `pnpm install`
3. Сгенерируйте Prisma Client:
   - `pnpm --filter @ot/server prisma:generate`
4. Запустите в dev-режиме:
   - `pnpm dev`

## Полезные команды

- Проверка типов: `pnpm typecheck`
- Сборка: `pnpm build`
