import { z } from "zod";
import { JournalStatus } from "./enums";

export const CreateJournalSchema = z.object({
  programId: z.string().uuid(),
  briefingDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  instructorId: z.string().uuid(),
  departmentId: z.string().uuid(),
  status: z.nativeEnum(JournalStatus).default(JournalStatus.Planned)
});

export const JournalRecordSchema = z.object({
  journalId: z.string().uuid(),
  employeeId: z.string().uuid(),
  signedAt: z.string().datetime().optional(),
  comment: z.string().max(500).optional()
});

export type CreateJournalDto = z.infer<typeof CreateJournalSchema>;
export type CreateJournalRecordDto = z.infer<typeof JournalRecordSchema>;
