import { z } from "zod";
import { Role, UserStatus } from "./enums";

export const CreateUserSchema = z.object({
  fullName: z.string().min(2).max(255),
  email: z.string().email(),
  role: z.nativeEnum(Role),
  departmentId: z.string().uuid(),
  positionId: z.string().uuid(),
  hireDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  status: z.nativeEnum(UserStatus).default(UserStatus.Active)
});

export const UpdateUserSchema = CreateUserSchema.partial();

export type CreateUserDto = z.infer<typeof CreateUserSchema>;
export type UpdateUserDto = z.infer<typeof UpdateUserSchema>;
