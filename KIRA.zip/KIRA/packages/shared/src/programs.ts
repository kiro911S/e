import { z } from "zod";
import { ProgramStatus } from "./enums";

export const ProgramQuestionSchema = z.object({
  text: z.string().min(3).max(1000),
  order: z.number().int().nonnegative(),
  isRequired: z.boolean().default(true)
});

export const CreateProgramSchema = z.object({
  title: z.string().min(3).max(255),
  description: z.string().max(2000).optional(),
  briefingTypeId: z.string().uuid(),
  status: z.nativeEnum(ProgramStatus).default(ProgramStatus.Draft),
  questions: z.array(ProgramQuestionSchema).min(1)
});

export type ProgramQuestionDto = z.infer<typeof ProgramQuestionSchema>;
export type CreateProgramDto = z.infer<typeof CreateProgramSchema>;
