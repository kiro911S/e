export declare enum Role {
    Guest = "Guest",
    Employee = "Employee",
    Inspector = "Inspector",
    Admin = "Admin"
}
export declare enum UserStatus {
    Active = "Active",
    Inactive = "Inactive"
}
export declare enum ProgramStatus {
    Draft = "Draft",
    Published = "Published",
    Archived = "Archived"
}
export declare enum JournalStatus {
    Planned = "Planned",
    InProgress = "InProgress",
    Completed = "Completed",
    Cancelled = "Cancelled"
}
export declare enum TestResultStatus {
    Passed = "Passed",
    Failed = "Failed"
}
export declare enum AuditAction {
    Create = "Create",
    Update = "Update",
    Delete = "Delete",
    Login = "Login",
    Export = "Export"
}
