import { z } from "zod";
import { ProgramStatus } from "./enums";
export declare const ProgramQuestionSchema: z.ZodObject<{
    text: z.ZodString;
    order: z.ZodNumber;
    isRequired: z.ZodDefault<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    text: string;
    order: number;
    isRequired: boolean;
}, {
    text: string;
    order: number;
    isRequired?: boolean | undefined;
}>;
export declare const CreateProgramSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    briefingTypeId: z.ZodString;
    status: z.ZodDefault<z.ZodNativeEnum<typeof ProgramStatus>>;
    questions: z.ZodArray<z.ZodObject<{
        text: z.ZodString;
        order: z.ZodNumber;
        isRequired: z.ZodDefault<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        text: string;
        order: number;
        isRequired: boolean;
    }, {
        text: string;
        order: number;
        isRequired?: boolean | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    status: ProgramStatus;
    title: string;
    briefingTypeId: string;
    questions: {
        text: string;
        order: number;
        isRequired: boolean;
    }[];
    description?: string | undefined;
}, {
    title: string;
    briefingTypeId: string;
    questions: {
        text: string;
        order: number;
        isRequired?: boolean | undefined;
    }[];
    status?: ProgramStatus | undefined;
    description?: string | undefined;
}>;
export type ProgramQuestionDto = z.infer<typeof ProgramQuestionSchema>;
export type CreateProgramDto = z.infer<typeof CreateProgramSchema>;
