export enum Role {
  Guest = "Guest",
  Employee = "Employee",
  Inspector = "Inspector",
  Admin = "Admin"
}

export enum UserStatus {
  Active = "Active",
  Inactive = "Inactive"
}

export enum ProgramStatus {
  Draft = "Draft",
  Published = "Published",
  Archived = "Archived"
}

export enum JournalStatus {
  Planned = "Planned",
  InProgress = "InProgress",
  Completed = "Completed",
  Cancelled = "Cancelled"
}

export enum TestResultStatus {
  Passed = "Passed",
  Failed = "Failed"
}

export enum AuditAction {
  Create = "Create",
  Update = "Update",
  Delete = "Delete",
  Login = "Login",
  Export = "Export"
}
