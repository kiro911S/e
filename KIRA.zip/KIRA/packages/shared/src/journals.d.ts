import { z } from "zod";
import { JournalStatus } from "./enums";
export declare const CreateJournalSchema: z.ZodObject<{
    programId: z.ZodString;
    briefingDate: z.ZodString;
    instructorId: z.ZodString;
    departmentId: z.ZodString;
    status: z.ZodDefault<z.ZodNativeEnum<typeof JournalStatus>>;
}, "strip", z.ZodTypeAny, {
    status: JournalStatus;
    programId: string;
    briefingDate: string;
    instructorId: string;
    departmentId: string;
}, {
    programId: string;
    briefingDate: string;
    instructorId: string;
    departmentId: string;
    status?: JournalStatus | undefined;
}>;
export declare const JournalRecordSchema: z.ZodObject<{
    journalId: z.ZodString;
    employeeId: z.ZodString;
    signedAt: z.ZodOptional<z.ZodString>;
    comment: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    journalId: string;
    employeeId: string;
    signedAt?: string | undefined;
    comment?: string | undefined;
}, {
    journalId: string;
    employeeId: string;
    signedAt?: string | undefined;
    comment?: string | undefined;
}>;
export type CreateJournalDto = z.infer<typeof CreateJournalSchema>;
export type CreateJournalRecordDto = z.infer<typeof JournalRecordSchema>;
