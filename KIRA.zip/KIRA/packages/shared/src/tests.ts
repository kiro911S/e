import { z } from "zod";
import { TestResultStatus } from "./enums";

export const TestAnswerSchema = z.object({
  questionId: z.string().uuid(),
  answer: z.string().min(1).max(1000)
});

export const SubmitTestSchema = z.object({
  journalId: z.string().uuid(),
  answers: z.array(TestAnswerSchema).min(1)
});

export type TestAnswerDto = z.infer<typeof TestAnswerSchema>;
export type SubmitTestDto = z.infer<typeof SubmitTestSchema>;
