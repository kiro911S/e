import { z } from "zod";
import { TestResultStatus } from "./enums";
export declare const TestAnswerSchema: z.ZodObject<{
    questionId: z.ZodString;
    answer: z.ZodString;
}, "strip", z.ZodTypeAny, {
    questionId: string;
    answer: string;
}, {
    questionId: string;
    answer: string;
}>;
export declare const SubmitTestSchema: z.ZodObject<{
    journalId: z.ZodString;
    employeeId: z.ZodString;
    answers: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        answer: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        questionId: string;
        answer: string;
    }, {
        questionId: string;
        answer: string;
    }>, "many">;
    score: z.ZodNumber;
    status: z.ZodNativeEnum<typeof TestResultStatus>;
}, "strip", z.ZodTypeAny, {
    status: TestResultStatus;
    journalId: string;
    employeeId: string;
    answers: {
        questionId: string;
        answer: string;
    }[];
    score: number;
}, {
    status: TestResultStatus;
    journalId: string;
    employeeId: string;
    answers: {
        questionId: string;
        answer: string;
    }[];
    score: number;
}>;
export type TestAnswerDto = z.infer<typeof TestAnswerSchema>;
export type SubmitTestDto = z.infer<typeof SubmitTestSchema>;
