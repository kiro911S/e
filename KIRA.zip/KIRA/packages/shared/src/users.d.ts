import { z } from "zod";
import { Role, UserStatus } from "./enums";
export declare const CreateUserSchema: z.ZodObject<{
    fullName: z.ZodString;
    email: z.ZodString;
    role: z.ZodNativeEnum<typeof Role>;
    departmentId: z.ZodString;
    positionId: z.ZodString;
    hireDate: z.ZodString;
    status: z.ZodDefault<z.ZodNativeEnum<typeof UserStatus>>;
}, "strip", z.ZodTypeAny, {
    email: string;
    status: UserStatus;
    departmentId: string;
    fullName: string;
    role: Role;
    positionId: string;
    hireDate: string;
}, {
    email: string;
    departmentId: string;
    fullName: string;
    role: Role;
    positionId: string;
    hireDate: string;
    status?: UserStatus | undefined;
}>;
export declare const UpdateUserSchema: z.ZodObject<{
    fullName: z.ZodOptional<z.ZodString>;
    email: z.ZodOptional<z.ZodString>;
    role: z.ZodOptional<z.ZodNativeEnum<typeof Role>>;
    departmentId: z.ZodOptional<z.ZodString>;
    positionId: z.ZodOptional<z.ZodString>;
    hireDate: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodDefault<z.ZodNativeEnum<typeof UserStatus>>>;
}, "strip", z.ZodTypeAny, {
    email?: string | undefined;
    status?: UserStatus | undefined;
    departmentId?: string | undefined;
    fullName?: string | undefined;
    role?: Role | undefined;
    positionId?: string | undefined;
    hireDate?: string | undefined;
}, {
    email?: string | undefined;
    status?: UserStatus | undefined;
    departmentId?: string | undefined;
    fullName?: string | undefined;
    role?: Role | undefined;
    positionId?: string | undefined;
    hireDate?: string | undefined;
}>;
export type CreateUserDto = z.infer<typeof CreateUserSchema>;
export type UpdateUserDto = z.infer<typeof UpdateUserSchema>;
