import { z } from "zod";

export const DepartmentSchema = z.object({
  name: z.string().min(2).max(255),
  code: z.string().min(1).max(32)
});

export const PositionSchema = z.object({
  name: z.string().min(2).max(255)
});

export const BriefingTypeSchema = z.object({
  name: z.string().min(2).max(255),
  periodicityMonths: z.number().int().positive().max(36)
});

export type CreateDepartmentDto = z.infer<typeof DepartmentSchema>;
export type CreatePositionDto = z.infer<typeof PositionSchema>;
export type CreateBriefingTypeDto = z.infer<typeof BriefingTypeSchema>;
