import { z } from "zod";
export declare const ReportFilterSchema: z.ZodObject<{
    from: z.ZodString;
    to: z.ZodString;
    departmentId: z.ZodOptional<z.ZodString>;
    programId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    from: string;
    to: string;
    programId?: string | undefined;
    departmentId?: string | undefined;
}, {
    from: string;
    to: string;
    programId?: string | undefined;
    departmentId?: string | undefined;
}>;
export declare const ReportItemSchema: z.ZodObject<{
    departmentName: z.ZodString;
    totalEmployees: z.ZodNumber;
    completed: z.ZodNumber;
    failed: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    departmentName: string;
    totalEmployees: number;
    completed: number;
    failed: number;
}, {
    departmentName: string;
    totalEmployees: number;
    completed: number;
    failed: number;
}>;
export type ReportFilterDto = z.infer<typeof ReportFilterSchema>;
export type ReportItemDto = z.infer<typeof ReportItemSchema>;
