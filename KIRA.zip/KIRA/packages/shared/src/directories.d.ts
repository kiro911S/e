import { z } from "zod";
export declare const DepartmentSchema: z.ZodObject<{
    name: z.ZodString;
    code: z.ZodString;
}, "strip", z.ZodTypeAny, {
    code: string;
    name: string;
}, {
    code: string;
    name: string;
}>;
export declare const PositionSchema: z.ZodObject<{
    name: z.ZodString;
}, "strip", z.ZodTypeAny, {
    name: string;
}, {
    name: string;
}>;
export declare const BriefingTypeSchema: z.ZodObject<{
    name: z.ZodString;
    periodicityMonths: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    name: string;
    periodicityMonths: number;
}, {
    name: string;
    periodicityMonths: number;
}>;
export type CreateDepartmentDto = z.infer<typeof DepartmentSchema>;
export type CreatePositionDto = z.infer<typeof PositionSchema>;
export type CreateBriefingTypeDto = z.infer<typeof BriefingTypeSchema>;
