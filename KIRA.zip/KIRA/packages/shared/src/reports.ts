import { z } from "zod";

export const ReportFilterSchema = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  departmentId: z.string().uuid().optional(),
  programId: z.string().uuid().optional()
});

export const ReportItemSchema = z.object({
  departmentName: z.string(),
  totalEmployees: z.number().int().nonnegative(),
  completed: z.number().int().nonnegative(),
  failed: z.number().int().nonnegative()
});

export type ReportFilterDto = z.infer<typeof ReportFilterSchema>;
export type ReportItemDto = z.infer<typeof ReportItemSchema>;
